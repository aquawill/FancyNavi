-- ----------------------------------------------------------------------------
-- Copyright (C) 2012 - 2014 HERE Global B.V., including its affiliated companies.
--
-- These coded instructions, statements, and computer programs contain
-- unpublished proprietary information of HERE Global B.V., and
-- are copy protected by law. They may not be disclosed to third parties
-- or copied or duplicated in any form, in whole or in part, without the
-- specific, prior written permission of HERE Global B.V.
-- ---------------------------------------------------------------------------- 
--      Authors: Fabian TP Riek, Bill King
-- ----------------------------------------------------------------------------

function replace(input, search_str, replace_str)
    return string.gsub(input, "^"..search_str.."[%.]?$", replace_str)
end


function contains(table, element, casesensitive)
  casesensitive = casesensitive or true
  for _, value in pairs(table) do
    if casesenesitive == true then
        if value == element then
          return true
        end
    else
        if value:lower() == element:lower() then
          return true
        end
    end
  end
  return false
end


function lang_spec_abbr(token)	-- Language specific abbreviation rules

    local words = split_token(token)

    -- no cardinal abbreviations for Chinese Mandarin Taiwan
    local has_cardinal = false

    for i = 1, table.getn( words ) do
        local word = words[i][1]
        -- all but last word rules...
        if i < table.getn( words ) then

        end

        -- last word rules
        if i == table.getn( words ) then
            -- Expansion of abbreviations that are at the end of street names
        end
        
        words[i][1] = word
    end

    -- re-construct the token based on the components
    token = ""
    for i = 1, table.getn(words) do
        token = token..words[i][1]..words[i][2]
    end

    return token

end


function checkMultiPlurals( distance, usedUnit, isFollow )
    return distance, usedUnit
end


function languageSpecificMods( result_sentence )
    return result_sentence
end


function can_shorten( article, noun )
    return false, { ["ortho"] = article }
end


abbr_begin = {
}

abbr_end = {
}

abbr_cs = {
}

abbr_misc = {
}
