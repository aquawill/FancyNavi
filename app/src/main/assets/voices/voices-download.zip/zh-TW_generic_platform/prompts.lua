-- ----------------------------------------------------------------------------
-- Copyright (C) 2012 - 2013 HERE Global B.V., including its affiliated companies.
--
-- These coded instructions, statements, and computer programs contain
-- unpublished proprietary information of HERE Global B.V., and
-- are copy protected by law. They may not be disclosed to third parties
-- or copied or duplicated in any form, in whole or in part, without the
-- specific, prior written permission of HERE Global B.V.
-- ---------------------------------------------------------------------------- 
--      Author: Lucian Machison
-- ----------------------------------------------------------------------------
--      Voice Prompts: zh-TW  Mandarin Chinese Taiwan

street_article = nil -- in taiwanese no street-name articles are used.

nG_prepositions = {	-- prepositions code for natural guidance, delivered by navteq, no additional translation needed
    ["CHTAAFTR"] = "之後", -- After
    ["CHTBATXX"] = "在", -- At/At the…
    ["CHTABFOR"] = "之前", -- Before/Before the
    ["CHTBTHRU"] = "穿過", -- Throuh(for tunnel usage)
    ["CHTBONTO"] = "下", -- Onto/Onto the (for bridge usage)
    ["CHTBPAST"] = "經過", -- Pass
    ["NONE"] = "", -- leave this entry, it's important
}

nG_elements = { -- natural guidance traffic light command elements
	[1] = "在下個紅綠燈", -- at the next traffic light
	[2] = "在第二個紅綠燈", -- at the second traffic light
	[3] = "在第三個紅綠燈", -- at the third traffic light
	["UNDEFINED"] = "",
}

unit_after = { -- Units to be used in sentences like After xx kilometers turn ...
	["MILE"] = "英里", -- mile
	["YARDS"] = "碼", -- yards
	["FEET"] = "英呎", -- feet
	["KILOMETER"] = "公里", -- kilometer
	["METERS"] = "公尺", -- meters
	["METER"] = "公尺", -- meter
	["KILOMETERS"] = "公里", -- kilometers
	["MILES"] = "英里", -- miles
	["UNDEFINED"] = "",
}

unit_follow = { -- Units to be used in sentences like Follow the road for xx kilometers.
	["MILE"] = "英里", -- mile
	["YARDS"] = "碼", -- yards
	["FEET"] = "英呎", -- feet
	["KILOMETER"] = "公里", -- kilometer
	["METERS"] = "公尺", -- meters
	["METER"] = "公尺", -- meter
	["KILOMETERS"] = "公里", -- kilometers
	["MILES"] = "英里", -- miles
	["UNDEFINED"] = "",
}

dist = { --
	["a"] = "一公里", -- one kilometer
	["b"] = "一英里", -- one mile
	["c"] = "四分之一英里", -- a quarter of a mile
	["d"] = "半英里", -- half a mile
	["e"] = "四分之三英里", -- three quarters of a mile
	["UNDEFINED"] = "",
}

exit_number_roundabout = { -- exit numbers for roundabouts in car navigation
	[1] = "從第一個出口離開", -- take the first exit
	[2] = "從第二個出口離開", -- take the second exit
	[3] = "從第三個出口離開", -- take the third exit
	[4] = "從第四個出口離開", -- take the fourth exit
	[5] = "從第五個出口離開", -- take the fifth exit
	[6] = "從第六個出口離開", -- take the sixth exit
	[7] = "從第七個出口離開", -- take the seventh exit
	[8] = "從第八個出口離開", -- take the eighth exit
	[9] = "從第九個出口離開", -- take the ninth exit
	[10] = "從第十個出口離開", -- take the tenth exit
	[11] = "從第十一個出口離開", -- take the eleventh exit
	[12] = "從第十二個出口離開", -- take the twelfth exit
	["UNDEFINED"] = "",
}

orientation = { -- Heading directions for walk commands, e.g. Head north on Oxford Street
	["NORTH"] = "北", -- north
	["NORTH_EAST"] = "東北", -- northeast
	["EAST"] = "東", -- east
	["SOUTH_EAST"] = "東南", -- southeast
	["SOUTH"] = "南", -- south
	["SOUTH_WEST"] = "西南", -- southwest
	["WEST"] = "西", -- west
	["NORTH_WEST"] = "西北", -- northwest
	["UNDEFINED"] = "",
}

turn_number_ped = { -- exit numbers for roundabouts in walk navigation
	[1] = "然後在第一條街 !STREET! 轉彎", -- and turn at the first street !STREET!
	[2] = "然後在第二條街 !STREET! 轉彎", -- and turn at the second street !STREET!
	[3] = "然後在第三條街 !STREET! 轉彎", -- and turn at the third street !STREET!
	["UNDEFINED"] = "",
}

commands_common = { -- Common commands for car & ped navigation.
	-- empty command
	["00000000"] = " ",
	-- 1: !EXIT_NO_ROUNDABOUT! at the end of the road at the roundabout towards !SIGNPOST!
	["c00c0zc0"] = "在道路的終點 請繞圓環行駛， !EXIT_NO_ROUNDABOUT! !BREAK:200! 往 !SIGNPOST!",
	-- 2: !EXIT_NO_ROUNDABOUT! at the end of the road at the roundabout onto !STREET!
	["c00c0zb0"] = "在道路的終點 請繞圓環行駛， !EXIT_NO_ROUNDABOUT! 進入 !STREET!",
	-- 3: !EXIT_NO_ROUNDABOUT! at the end of the road at the roundabout
	["c00c0z00"] = "在道路的終點 請繞圓環行駛， !EXIT_NO_ROUNDABOUT!",
	-- 4: and then take the exit !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00d000x"] = "然後 !NG_COMMAND_2! 請從出口離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 5: and then enter the motorway !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00f000x"] = "然後 !NG_COMMAND_2! 進入高速公路 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 6: and then take the exit !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00j000x"] = "然後 !NG_COMMAND_2! 請從出口離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 7: and then make a u turn !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00e000x"] = "然後 !NG_COMMAND_2! 請迴轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 8: and then enter the urban motorway !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00i000x"] = "然後 !NG_COMMAND_2! 進入市區快速道路 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 9: and then take the exit !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00g000x"] = "然後 !NG_COMMAND_2! 請從出口離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 10: and then take the middle lane !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00o000x"] = "然後 !NG_COMMAND_2! 請走中間車道 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 11: and then turn left !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00v000x"] = "然後 !NG_COMMAND_2! 請向左轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 12: and then turn slightly left !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00w000x"] = "然後 !NG_COMMAND_2! 請小幅度左轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 13: and then turn sharply left !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00u000x"] = "然後 !NG_COMMAND_2! 請向左急轉彎 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 14: and then turn sharply right !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00s000x"] = "然後 !NG_COMMAND_2! 請向右急轉彎 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 15: and then turn right !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00r000x"] = "然後 !NG_COMMAND_2! 請向右轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 16: and then keep right !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00p000x"] = "然後 !NG_COMMAND_2! 請保持右側行駛 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 17: and then make a u turn !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00t000x"] = "然後 !NG_COMMAND_2! 請迴轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 18: and then keep left !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00x000x"] = "然後 !NG_COMMAND_2! 請保持左側行駛 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 19: and then turn slightly right !NG_COMMAND_2! towards !STREET_2! !SIGNPOST_2!
	["h00q000x"] = "然後 !NG_COMMAND_2! 請小幅度右轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 20: and then !EXIT_NO_ROUNDABOUT! at the roundabout towards !STREET_2! !SIGNPOST_2!
	["h000cz0x"] = "然後 請繞圓環行駛， !EXIT_NO_ROUNDABOUT! !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 21: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take the exit
	["bl0o000j"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口離開,",
	-- 22: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take the exit
	["bl0x000j"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口離開,",
	-- 23: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take the exit
	["bl0p000j"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口離開,",
	-- 24: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take the exit
	["bl0n000j"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口離開,",
	-- 25: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! and take the exit
	["bl0o00fj"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道 然後請從出口離開",
	-- 26: After !DIST! !UNIT! take the exit !NG_COMMAND_1!
	["bl00000j"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請從出口離開",
	-- 27: After !DIST! !UNIT! keep left !NG_COMMAND_1! and take the exit
	["bl0x00fj"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛 然後請從出口離開",
	-- 28: After !DIST! !UNIT! keep right !NG_COMMAND_1! and take the exit
	["bl0p00fj"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛 然後請從出口離開",
	-- 29: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! and take the exit
	["bl0n00fj"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後請從出口離開",
	-- 30: Now take the exit !NG_COMMAND_1!
	["a000000g"] = "現在 !NG_COMMAND_1! 請從出口離開",
	-- 31: After !DIST! !UNIT! take exit !EXIT_NUMBER! towards !STREET_2! !SIGNPOST_2!
	["bl000e0x"] = "!DIST! !UNIT! 之後 請從出口 !EXIT_NUMBER! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 32: Now go straight ahead !NG_COMMAND_1! , enter the urban motorway
	["a00ni000"] = "現在 !NG_COMMAND_1! 請直走, 進入市區快速道路,",
	-- 33: and then go straight ahead towards !STREET_2! !SIGNPOST_2!
	["h00n000x"] = "然後 請直走 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 34: Now take the middle lane !NG_COMMAND_1! , take the exit
	["a00o000j"] = "現在 !NG_COMMAND_1! 請走中間車道, 請從出口離開,",
	-- 35: Now keep left !NG_COMMAND_1! , take the exit
	["a00x000j"] = "現在 !NG_COMMAND_1! 請保持左側行駛, 請從出口離開,",
	-- 36: Now keep right !NG_COMMAND_1!  , take the exit
	["a00p000j"] = "現在 !NG_COMMAND_1! 請保持右側行駛, 請從出口離開,",
	-- 37: Now go straight ahead !NG_COMMAND_1! and take the exit
	["a00n00fj"] = "現在 !NG_COMMAND_1! 請直走 然後請從出口離開",
	-- 38: Now go straight ahead !NG_COMMAND_1! , take the exit
	["a00n000j"] = "現在 !NG_COMMAND_1! 請直走, 請從出口離開,",
	-- 39: Now take the middle lane !NG_COMMAND_1! and take the exit
	["a00o00fj"] = "現在 !NG_COMMAND_1! 請走中間車道 然後請從出口離開",
	-- 40: Now take the exit !NG_COMMAND_1!
	["a000000j"] = "現在 !NG_COMMAND_1! 請從出口離開",
	-- 41: Now keep left !NG_COMMAND_1! and take the exit
	["a00x00fj"] = "現在 !NG_COMMAND_1! 請保持左側行駛 然後請從出口離開",
	-- 42: Now keep right !NG_COMMAND_1! and take the exit
	["a00p00fj"] = "現在 !NG_COMMAND_1! 請保持右側行駛 然後請從出口離開",
	-- 43: Now go straight ahead !NG_COMMAND_1! and take the exit
	["a00n00fj"] = "現在 !NG_COMMAND_1! 請直走 然後請從出口離開",
	-- 44: and then you will reach your destination !NG_COMMAND_2! on !STREET!
	["h000ab00"] = "然後 !NG_COMMAND_2! 您即將 到達目的地 !STREET!",
	-- 45: After !DIST! !UNIT! turn left !NG_COMMAND_1! onto !STREET!
	["bl0v0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 進入 !STREET!",
	-- 46: Now keep right !NG_COMMAND_1! , enter the urban motorway
	["a00pi000"] = "現在 !NG_COMMAND_1! 請保持右側行駛, 進入市區快速道路,",
	-- 47: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the motorway
	["bl0nf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入高速公路,",
	-- 48: After !DIST! !UNIT! you will reach your destination !NG_COMMAND_1! on !STREET!
	["bl0a0b00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 您即將 在 !STREET! 到達 目的地",
	-- 49: and then immediately turn slightly right onto !STREET! towards !SIGNPOST!
	["j00q0ac0"] = "然後 立即 請小幅度右轉 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 50: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0o0edz"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! 離開 !SIGNPOST!, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 51: and then make a u turn !NG_COMMAND_2! onto !STREET!
	["h000ed00"] = "然後 !NG_COMMAND_2! 請迴轉 進入 !STREET!",
	-- 52: After !DIST! !UNIT! turn right !NG_COMMAND_1! towards !STREET!
	["bl0r0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 !BREAK:200! 往 !STREET!",
	-- 53: and then immediately make a u turn !NG_COMMAND_2! onto !STREET!
	["j000ed00"] = "然後 !NG_COMMAND_2! 立即 請迴轉 進入 !STREET!",
	-- 54: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0x0edz"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 55: Now turn right !NG_COMMAND_1! , enter the motorway
	["a00rf000"] = "現在 !NG_COMMAND_1! 請向右轉, 進入高速公路,",
	-- 56: After !DIST! !UNIT! turn left !NG_COMMAND_1! towards !STREET!
	["bl0v0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 !BREAK:200! 往 !STREET!",
	-- 57: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! towards !STREET!
	["bl0q0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 !BREAK:200! 往 !STREET!",
	-- 58: At the end of the road turn right !NG_COMMAND_1! , enter the motorway
	["c00rf000"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入高速公路,",
	-- 59: After !DIST! !UNIT! you will reach a stopover !NG_COMMAND_1!
	["bl0b0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 您即將到達休息站",
	-- 60: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take exit !EXIT_NUMBER! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0x0e0z"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 61: Now take the exit !NG_COMMAND_1!
	["a00d0000"] = "現在 !NG_COMMAND_1! 請從出口離開",
	-- 62: After !DIST! !UNIT! enter the motorway
	["bl00f000"] = "!DIST! !UNIT! 之後 進入高速公路",
	-- 63: and then take the exit !NG_COMMAND_2!
	["h00d0000"] = "然後 !NG_COMMAND_2! 請從出口離開",
	-- 64: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0qf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST! ,",
	-- 65: and then turn left !NG_COMMAND_2!
	["h00v0000"] = "然後 !NG_COMMAND_2! 請向左轉",
	-- 66: and then immediately turn left !NG_COMMAND_2!
	["j00v0000"] = "然後 !NG_COMMAND_2! 立即 請向左轉",
	-- 67: and then immediately make a u turn !NG_COMMAND_2!
	["j000e000"] = "然後 !NG_COMMAND_2! 立即 請迴轉",
	-- 68: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0uf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 69: At the end of the road turn sharply left !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["c00ui0c0"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 70: and then make a u turn !NG_COMMAND_2!
	["h000e000"] = "然後 !NG_COMMAND_2! 請迴轉",
	-- 71: At the end of the road turn right !NG_COMMAND_1! onto !STREET!
	["c00r0d00"] = "在道路的終點 !NG_COMMAND_1! 請向右轉 進入 !STREET!",
	-- 72: and then turn right, !STREET!
	["h00r0a00"] = "然後 請向右轉 !STREET!",
	-- 73: and then immediately take the exit !NG_COMMAND_2! towards !STREET!
	["j000dc00"] = "然後 !NG_COMMAND_2! 立即 請從出口離開 !BREAK:200! 往 !STREET!",
	-- 74: Now turn left !NG_COMMAND_1!
	["a00v0000"] = "現在 !NG_COMMAND_1! 請向左轉",
	-- 75: At the end of the road turn left !NG_COMMAND_1!
	["c00v0000"] = "在道路的終點 !NG_COMMAND_1! 請向左轉",
	-- 76: At the end of the road take the ferry !NG_COMMAND_1! towards !STREET!
	["c00m0c00"] = "在道路的終點 !NG_COMMAND_1! 請上渡船 !BREAK:200! 往 !STREET!",
	-- 77: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1!
	["bl0o0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道",
	-- 78: After !DIST! !UNIT! keep left !NG_COMMAND_1! and take the exit
	["bl0x00fg"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛 然後 請從出口離開",
	-- 79: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER! towards !STREET_2! !SIGNPOST_2!
	["bl0o0e0x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 80: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0ofac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 81: Now go straight ahead !NG_COMMAND_1! and take the exit
	["a00n00fg"] = "現在 !NG_COMMAND_1! 請直走 然後 請從出口離開",
	-- 82: Now take the exit !NG_COMMAND_1! towards !STREET!
	["a00d0c00"] = "現在 !NG_COMMAND_1! 請從出口離開 !BREAK:200! 往 !STREET!",
	-- 83: Now keep left !NG_COMMAND_1! , take the exit
	["a00x000g"] = "現在 !NG_COMMAND_1! 請保持左側行駛, 請從出口離開,",
	-- 84: and then you will reach a stopover !NG_COMMAND_2!
	["h000b000"] = "然後 !NG_COMMAND_2! 您即將到達休息站",
	-- 85: At the end of the road turn slightly right !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["c00qi0c0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 86: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0sf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 87: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0piac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 88: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST!
	["bl0x0ed0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開,",
	-- 89: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2!
	["bl0p0edy"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開, 然後請繼續在 !STREET_2! 行駛",
	-- 90: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0ti0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 91: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! onto !STREET!
	["bl0w0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 進入 !STREET!",
	-- 92: At the end of the road turn slightly left !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["c00wi0c0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 93: After !DIST! !UNIT! !EXIT_NO_ROUNDABOUT! !NG_COMMAND_1! at the roundabout
	["bl0c0z00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請繞圓環行駛， !EXIT_NO_ROUNDABOUT!",
	-- 94: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! towards !STREET_2! !SIGNPOST_2!
	["bl0o0edx"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 95: At the end of the road make a u turn !NG_COMMAND_1!
	["c00t0000"] = "在道路的終點 !NG_COMMAND_1! 請迴轉",
	-- 96: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0ni0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 97: After the junction keep right !NG_COMMAND_1!
	["bz0p0000"] = "經過交叉口後 !NG_COMMAND_1! 請保持右側行駛",
	-- 98: After the junction go straight ahead !NG_COMMAND_1!
	["bz0n0000"] = "經過交叉口後 !NG_COMMAND_1! 請直走",
	-- 99: and then make a u turn !NG_COMMAND_2!
	["h00t0000"] = "然後 !NG_COMMAND_2! 請迴轉",
	-- 100: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! and take the exit
	["bl0n00fg"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後 請從出口離開",
	-- 101: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0uiac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 102: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0n000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 103: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2!
	["bl0n0edy"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開, 然後請繼續在 !STREET_2! 行駛",
	-- 104: and then immediately turn sharply right onto !STREET! towards !SIGNPOST!
	["j00s0ac0"] = "然後 立即 請向右急轉彎 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 105: After !DIST! !UNIT! take the ferry !NG_COMMAND_1!
	["bl0m0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請上渡船",
	-- 106: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0oi0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 107: At the end of the road turn left !NG_COMMAND_1! , enter the urban motorway !STREET!
	["c00via00"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入市區快速道路 !STREET!,",
	-- 108: and then turn sharply right !NG_COMMAND_2! towards !SIGNPOST!
	["h00s00c0"] = "然後 !NG_COMMAND_2! 請向右急轉彎 !BREAK:200! 往 !SIGNPOST!",
	-- 109: Now take the middle lane !NG_COMMAND_1!
	["a00o0000"] = "現在 !NG_COMMAND_1! 請走中間車道",
	-- 110: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2!
	["bl0o0edy"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! 離開 !SIGNPOST!, 然後請繼續在 !STREET_2! 行駛",
	-- 111: At the end of the road turn slightly right !NG_COMMAND_1!
	["c00q0000"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉",
	-- 112: and then take the middle lane !NG_COMMAND_2!
	["h00o0000"] = "然後 !NG_COMMAND_2! 請走中間車道",
	-- 113: Now keep right !NG_COMMAND_1! and take the exit
	["a00p00fg"] = "現在 !NG_COMMAND_1! 請保持右側行駛 然後 請從出口離開",
	-- 114: and then immediately take the middle lane !NG_COMMAND_2!
	["j00o0000"] = "然後 !NG_COMMAND_2! 立即 請走中間車道",
	-- 115: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0wfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 116: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! towards !STREET!
	["bl0t0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉 !BREAK:200! 往 !STREET!",
	-- 117: and then take the ferry !NG_COMMAND_2!
	["h00m0000"] = "然後 !NG_COMMAND_2! 請上渡船",
	-- 118: Now turn slightly right !NG_COMMAND_1!
	["a00q0000"] = "現在 !NG_COMMAND_1! 請小幅度右轉",
	-- 119: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the urban motorway
	["bl0ri000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入市區快速道路,",
	-- 120: and then keep left !NG_COMMAND_2! towards !STREET!
	["h00x0c00"] = "然後 !NG_COMMAND_2! 請保持左側行駛 !BREAK:200! 往 !STREET!",
	-- 121: and then immediately turn slightly right !NG_COMMAND_2! onto !STREET!
	["j00q0d00"] = "然後 !NG_COMMAND_2! 立即 請小幅度右轉 進入 !STREET!",
	-- 122: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the motorway
	["bl0rf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入高速公路,",
	-- 123: After !DIST! !UNIT! make a u turn !NG_COMMAND_1!
	["bl0e0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉",
	-- 124: and then enter the urban motorway !NG_COMMAND_2! towards !SIGNPOST!
	["h00i00c0"] = "然後 !NG_COMMAND_2! 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!",
	-- 125: At the end of the road take the ferry !NG_COMMAND_1!
	["c00m0000"] = "在道路的終點 !NG_COMMAND_1! 請上渡船",
	-- 126: Now take the ferry !NG_COMMAND_1!
	["a00m0000"] = "現在 !NG_COMMAND_1! 請上渡船",
	-- 127: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! towards !STREET!
	["bl0s0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 !BREAK:200! 往 !STREET!",
	-- 128: At the end of the road turn sharply left !NG_COMMAND_1! , enter the motorway !STREET!
	["c00ufa00"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路 !STREET!,",
	-- 129: At the end of the road make a u turn !NG_COMMAND_1! , enter the motorway !STREET!
	["c00tfa00"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入高速公路 !STREET!,",
	-- 130: After !DIST! !UNIT! enter the motorway !STREET! towards !SIGNPOST!
	["bl00fac0"] = "!DIST! !UNIT! 之後 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 131: and then enter the urban motorway !STREET! towards !SIGNPOST!
	["h00i0ac0"] = "然後 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 132: and then immediately take the middle lane !NG_COMMAND_2! towards !SIGNPOST!
	["j00o00c0"] = "然後 !NG_COMMAND_2! 立即 請走中間車道 !BREAK:200! 往 !SIGNPOST!",
	-- 133: and then take the middle lane !NG_COMMAND_2! onto !STREET!
	["h00o0d00"] = "然後 !NG_COMMAND_2! 請走中間車道 進入 !STREET!",
	-- 134: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER!
	["bl0o0e00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! 離開,",
	-- 135: After !DIST! !UNIT! turn left !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0via00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入市區快速道路 !STREET!,",
	-- 136: At the end of the road turn sharply left !NG_COMMAND_1! , enter the motorway
	["c00uf000"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路,",
	-- 137: Now turn sharply left !NG_COMMAND_1! , enter the motorway
	["a00uf000"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路,",
	-- 138: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST!
	["bl0p0ed0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開,",
	-- 139: and then immediately enter the urban motorway !NG_COMMAND_2!
	["j000i000"] = "然後 !NG_COMMAND_2! 立即 進入市區快速道路",
	-- 140: At the end of the road turn left !NG_COMMAND_1! , enter the motorway !STREET!
	["c00vfa00"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入高速公路 !STREET!,",
	-- 141: and then enter the urban motorway !NG_COMMAND_2!
	["h000i000"] = "然後 !NG_COMMAND_2! 進入市區快速道路",
	-- 142: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0qfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 143: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1!
	["bl0w0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉",
	-- 144: Now enter the urban motorway
	["a000i000"] = "現在 進入市區快速道路",
	-- 145: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0xia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入市區快速道路 !STREET!,",
	-- 146: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST!
	["bl0n0ed0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開,",
	-- 147: and then immediately turn sharply left !NG_COMMAND_2! towards !SIGNPOST!
	["j00u00c0"] = "然後 !NG_COMMAND_2! 立即 請向左急轉彎 !BREAK:200! 往 !SIGNPOST!",
	-- 148: Now go straight ahead !NG_COMMAND_1! , take the exit
	["a00n000g"] = "現在 !NG_COMMAND_1! 請直走, 請從出口離開,",
	-- 149: At the end of the road turn sharply left !NG_COMMAND_1! , enter the urban motorway !STREET!
	["c00uia00"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路 !STREET!,",
	-- 150: and then turn sharply left !NG_COMMAND_2! towards !SIGNPOST!
	["h00u00c0"] = "然後 !NG_COMMAND_2! 請向左急轉彎 !BREAK:200! 往 !SIGNPOST!",
	-- 151: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! onto !STREET!
	["bl0s0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 進入 !STREET!",
	-- 152: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the motorway
	["bl0tf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入高速公路,",
	-- 153: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1!
	["bl0q0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉",
	-- 154: and then take the exit !NG_COMMAND_2!
	["h00g0000"] = "然後 !NG_COMMAND_2! 請從出口離開",
	-- 155: At the end of the road turn sharply right !NG_COMMAND_1!
	["c00s0000"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎",
	-- 156: and then make a u turn !NG_COMMAND_2!
	["h00e0000"] = "然後 !NG_COMMAND_2! 請迴轉",
	-- 157: Now turn sharply right !NG_COMMAND_1!
	["a00s0000"] = "現在 !NG_COMMAND_1! 請向右急轉彎",
	-- 158: and then immediately keep right !NG_COMMAND_2! onto !STREET!
	["j00p0d00"] = "然後 !NG_COMMAND_2! 立即 請保持右側行駛 進入 !STREET!",
	-- 159: At the end of the road make a u turn !NG_COMMAND_1!
	["c00e0000"] = "在道路的終點 !NG_COMMAND_1! 請迴轉",
	-- 160: and then turn sharply right !NG_COMMAND_2!
	["h00s0000"] = "然後 !NG_COMMAND_2! 請向右急轉彎",
	-- 161: At the end of the road turn sharply left !NG_COMMAND_1! towards !STREET!
	["c00u0c00"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎 !BREAK:200! 往 !STREET!",
	-- 162: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0tf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 163: At the end of the road turn slightly left !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["c00wfac0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 164: At the end of the road turn slightly left !NG_COMMAND_1! , enter the urban motorway
	["c00wi000"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路,",
	-- 165: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0ofa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入高速公路 !STREET!,",
	-- 166: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the urban motorway
	["bl0ti000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入市區快速道路,",
	-- 167: At the end of the road turn slightly right !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["c00qiac0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 168: Now turn right !NG_COMMAND_1! take the exit
	["a00r000g"] = "現在 !NG_COMMAND_1! 請向右轉, 請從出口離開,",
	-- 169: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the urban motorway
	["bl0qi000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路,",
	-- 170: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! onto !STREET!
	["bl0q0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 進入 !STREET!",
	-- 171: After !DIST! !UNIT! keep right !NG_COMMAND_1! and take the exit
	["bl0p00fg"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛 然後 請從出口離開",
	-- 173: At the end of the road turn sharply right !NG_COMMAND_1! towards !STREET!
	["c00s0c00"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎 !BREAK:200! 往 !STREET!",
	-- 174: Now turn left !NG_COMMAND_1! , enter the urban motorway
	["a00vi000"] = "現在 !NG_COMMAND_1! 請向左轉, 進入市區快速道路,",
	-- 175: At the end of the road turn left !NG_COMMAND_1! , enter the urban motorway
	["c00vi000"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入市區快速道路 !STREET!,",
	-- 176: Now turn left !NG_COMMAND_1! and take the exit
	["a00v00fg"] = "現在 !NG_COMMAND_1! 請向左轉 然後 請從出口離開",
	-- 177: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0xfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入高速公路 !STREET!,",
	-- 178: After !DIST! !UNIT! !EXIT_NO_ROUNDABOUT! at the roundabout  towards !SIGNPOST!
	["bl0c0zc0"] = "!DIST! !UNIT! 之後 請繞圓環行駛， !EXIT_NO_ROUNDABOUT! !BREAK:200! 往 !SIGNPOST!",
	-- 179: At the end of the road make a u turn !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["c00tf0c0"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 180: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0si0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 181: At the end of the road you will reach a stopover !NG_COMMAND_1! on !STREET!
	["c00b0b00"] = "在道路的終點 !NG_COMMAND_1! 您即將 在 !STREET! 到達休息站",
	-- 182: After the junction turn slightly left !NG_COMMAND_1!
	["bz0w0000"] = "經過交叉口後 !NG_COMMAND_1! 請小幅度左轉",
	-- 183: At the end of the road turn slightly right !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["c00qfac0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 184: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1!
	["bl0s0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎",
	-- 185: and then turn left !STREET! towards !SIGNPOST!
	["h00v0ac0"] = "然後 在 !STREET! 請向左轉 !BREAK:200! 往 !SIGNPOST!",
	-- 186: and then keep right, !STREET!
	["h00p0a00"] = "然後 請保持右側行駛 !STREET!",
	-- 187: At the end of the road turn sharply right !NG_COMMAND_1! , enter the urban motorway on !STREET! towards !SIGNPOST!
	["c00siac0"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 188: At the end of the road turn left !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["c00vf0c0"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 189: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0tfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入高速公路 !STREET!,",
	-- 190: At the end of the road turn left !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["c00viac0"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 191: and then make a u turn !NG_COMMAND_2! towards !STREET!
	["h000ec00"] = "然後 !NG_COMMAND_2! 請迴轉 !BREAK:200! 往 !STREET!",
	-- 192: and then immediately make a u turn !NG_COMMAND_2! towards !STREET!
	["j000ec00"] = "然後 !NG_COMMAND_2! 立即 請迴轉 !BREAK:200! 往 !STREET!",
	-- 193: Now take the exit !NG_COMMAND_1! onto !STREET!
	["a00d0d00"] = "現在 !NG_COMMAND_1! 請從出口離開 進入 !STREET!",
	-- 194: and then take the exit !NG_COMMAND_2!
	["h000g000"] = "然後 !NG_COMMAND_2! 請從出口離開",
	-- 195: and then immediately take the middle lane, !STREET! towards !SIGNPOST!
	["j00o0ac0"] = "然後 立即 請走中間車道 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 196: and then immediately take the exit !NG_COMMAND_2!
	["j000g000"] = "然後 !NG_COMMAND_2! 立即 請從出口離開",
	-- 197: At the end of the road turn slightly right !NG_COMMAND_1! , enter the urban motorway !STREET!
	["c00qia00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路 !STREET!,",
	-- 198: and then enter the motorway !STREET! towards !SIGNPOST!
	["h000fac0"] = "然後 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 199: After !DIST! !UNIT! !EXIT_NO_ROUNDABOUT! at the roundabout onto !STREET!
	["bl0c0zb0"] = "!DIST! !UNIT! 之後 請繞圓環行駛， !EXIT_NO_ROUNDABOUT! 進入 !STREET!",
	-- 200: After !DIST! !UNIT! take the exit !NG_COMMAND_1! onto !STREET!
	["bl0d0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請從出口離開 進入 !STREET!",
	-- 201: Now turn right !NG_COMMAND_1! , enter the urban motorway
	["a00ri000"] = "現在 !NG_COMMAND_1! 請向右轉, 進入市區快速道路,",
	-- 202: At the end of the road turn right !NG_COMMAND_1! , enter the urban motorway
	["c00ri000"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入市區快速道路,",
	-- 203: You've reached your destination
	["y0000000"] = "您已經到達目的地",
	-- 204: You've reached your destination. The destination is on your right
	["yp000000"] = "您已經到達目的地。 目的地在您的右邊",
	-- 205: You've reached your destination. The destination is on your left
	["yq000000"] = "您已經到達目的地。 目的地在您的左邊",
	-- 206: !SET_AUDIO!beep!FREQUENCY!K.wav!SET_AUDIO!
	["x0000000"] = "!SET_AUDIO!beep!FREQUENCY!K.wav!SET_AUDIO! 前方有測速照相",
	-- 207: Route recalculation
	["w0000000"] = "重新規劃路線",
	-- 208: !SET_AUDIO!beep!FREQUENCY!K.wav!SET_AUDIO! Safety camera ahead
	["v0000000"] = "!SET_AUDIO!beep!FREQUENCY!K.wav!SET_AUDIO! 前方有測速照相",
	-- 209: !EXIT_NO_ROUNDABOUT! at the roundabout
	["000c0z00"] = "請繞圓環行駛， !EXIT_NO_ROUNDABOUT!",
	-- 210: Now go straight ahead !NG_COMMAND_1! enter the motorway
	["a00nf000"] = "現在 !NG_COMMAND_1! 請直走, 進入高速公路,",
	-- 211: You've reached a stopover. The stopover is on your right
	["zr000000"] = "您已經到達休息站。 休息站在您的右邊",
	-- 212: You've reached a stopover. The stopover is on your left
	["zs000000"] = "您已經到達休息站。 休息站在您的左邊",
	-- 213: You've reached a stopover
	["z0000000"] = "您已經到達休息站",
	-- 214: GPS signal has been restored
	["q0000000"] = "GPS訊號已連接",
	-- 215: GPS signal lost
	["p0000000"] = "遺失GPS訊號",
	-- 216: At the end of the road turn sharply right !NG_COMMAND_1! , enter the motorway !STREET!
	["c00sfa00"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路 !STREET!,",
	-- 217: No detour found around traffic
	["u0000000"] = "無法找到避開交通堵塞的繞行路徑",
	-- 218: Traffic on route, do you want to detour?
	["t0000000"] = "路線上有交通堵塞 是否繞行？",
	-- 219: !SET_AUDIO!speeding_beep!FREQUENCY!K.wav!SET_AUDIO!
	["r0000000"] = "!SET_AUDIO!speeding_beep!FREQUENCY!K.wav!SET_AUDIO!",
	-- 220: At the end of the road turn right !NG_COMMAND_1! , enter the motorway !STREET!
	["c00rfa00"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入高速公路 !STREET!,",
	-- 221: and then immediately go straight ahead, !STREET!
	["j00n0a00"] = "然後 立即 請直走 !STREET!",
	-- 222: At the end of the road turn slightly right !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["c00qf0c0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 223: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0riac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 224: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0pfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 225: At the end of the road make a u turn !NG_COMMAND_1! , enter the motorway
	["c00tf000"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入高速公路,",
	-- 226: Now make a u turn !NG_COMMAND_1! , enter the urban motorway
	["a00ti000"] = "現在 !NG_COMMAND_1! 請迴轉, 進入市區快速道路,",
	-- 227: Now make a u turn !NG_COMMAND_1! , enter the motorway
	["a00tf000"] = "現在 !NG_COMMAND_1! 請迴轉, 進入高速公路,",
	-- 228: After !DIST! !UNIT! you will reach a stopover !NG_COMMAND_1! on !STREET!
	["bl0b0b00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 您即將 在 !STREET! 到達休息站",
	-- 229: and then immediately take the second right !NG_COMMAND_2!
	["j00y0000"] = "然後 !NG_COMMAND_2! 立即 請從第二個路口右轉",
	-- 230: and then take the second right !NG_COMMAND_2!
	["h00y0000"] = "然後 !NG_COMMAND_2! 請從第二個路口右轉",
	-- 231: After !DIST! !UNIT! enter the urban motorway
	["bl00i000"] = "!DIST! !UNIT! 之後 進入市區快速道路",
	-- 232: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0pia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入市區快速道路 !STREET!,",
	-- 233: Now enter the motorway
	["a000f000"] = "現在 進入高速公路",
	-- 234: At the end of the road turn sharply right !NG_COMMAND_1! , enter the urban motorway
	["c00si000"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路,",
	-- 235: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0oia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入市區快速道路 !STREET!,",
	-- 236: At the end of the road turn slightly left !NG_COMMAND_1! onto !STREET!
	["c00w0d00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉 進入 !STREET!",
	-- 237: and then turn slightly left !NG_COMMAND_2!
	["h00w0000"] = "然後 !NG_COMMAND_2! 請小幅度左轉 !BREAK:200! 往",
	-- 238: and then immediately turn slightly left !NG_COMMAND_2!
	["j00w0000"] = "然後 !NG_COMMAND_2! 立即 請小幅度左轉",
	-- 239: and then immediately take the second right !NG_COMMAND_2! onto !STREET!
	["j00y0d00"] = "然後 !NG_COMMAND_2! 立即 請從第二個路口右轉 進入 !STREET!",
	-- 240: and then take the second right !NG_COMMAND_2! onto !STREET!
	["h00y0d00"] = "然後 !NG_COMMAND_2! 請從第二個路口右轉 進入 !STREET!",
	-- 241: and then immediately enter the motorway !NG_COMMAND_2!
	["j000f000"] = "然後 !NG_COMMAND_2! 立即 進入高速公路",
	-- 242: Now turn sharply right !NG_COMMAND_1! , enter the urban motorway
	["a00si000"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路,",
	-- 243: Now turn slightly left !NG_COMMAND_1!
	["a00w0000"] = "現在 !NG_COMMAND_1! 請小幅度左轉",
	-- 244: After the junction turn sharply right !NG_COMMAND_1!
	["bz0s0000"] = "經過交叉口後 !NG_COMMAND_1! 請向右急轉彎",
	-- 245: At the end of the road turn slightly left !NG_COMMAND_1!
	["c00w0000"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉",
	-- 246: and then enter the motorway !NG_COMMAND_2!
	["h000f000"] = "然後 !NG_COMMAND_2! 進入高速公路",
	-- 247: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the urban motorway
	["bl0wi000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路,",
	-- 248: Now keep right !NG_COMMAND_1!
	["a00p0000"] = "現在 !NG_COMMAND_1! 請保持右側行駛",
	-- 249: and then immediately keep left !NG_COMMAND_2! onto !STREET!
	["j00x0d00"] = "然後 !NG_COMMAND_2! 立即 請保持左側行駛 進入 !STREET!",
	-- 250: and then immediately turn right !STREET! towards !SIGNPOST!
	["j00r0ac0"] = "然後 立即 請向右轉 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 251: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0wfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路 !STREET!,",
	-- 252: and then keep right !NG_COMMAND_2!
	["h00p0000"] = "然後 !NG_COMMAND_2! 請保持右側行駛",
	-- 253: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the motorway
	["bl0xf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入高速公路,",
	-- 254: and then take the exit !NG_COMMAND_2! towards !STREET!
	["h000gc00"] = "然後 !NG_COMMAND_2! 請從出口離開 !BREAK:200! 往 !STREET!",
	-- 255: At the end of the road make a u turn !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["c00ti0c0"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 256: and then immediately take the second left !NG_COMMAND_2! onto !STREET!
	["j00z0d00"] = "然後 !NG_COMMAND_2! 立即 請從第二個路口左轉 進入 !STREET!",
	-- 257: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0p0edz"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 258: and then take the middle lane !NG_COMMAND_2! towards !STREET!
	["h00o0c00"] = "然後 !NG_COMMAND_2! 請走中間車道 !BREAK:200! 往 !STREET!",
	-- 259: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0nf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 260: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0of0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 261: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! towards !STREET!
	["bl0w0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 !BREAK:200! 往 !STREET!",
	-- 262: and then take the second left !NG_COMMAND_2! onto !STREET!
	["h00z0d00"] = "然後 !NG_COMMAND_2! 請從第二個路口左轉 進入 !STREET!",
	-- 263: After !DIST! !UNIT! turn right !NG_COMMAND_1!
	["bl0r0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉",
	-- 264: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER! towards !STREET_2! !SIGNPOST_2!
	["bl0p0e0x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 265: After the junction turn left !NG_COMMAND_1!
	["bz0v0000"] = "經過交叉口後 !NG_COMMAND_1! 請向左轉",
	-- 266: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0q000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 267: At the end of the road turn slightly left !NG_COMMAND_1! , enter the urban motorway !STREET!
	["c00wia00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路 !STREET!,",
	-- 268: and then take the exit !NG_COMMAND_2!
	["h000d000"] = "然後 !NG_COMMAND_2! 請從出口離開",
	-- 269: At the end of the road make a u turn !NG_COMMAND_1! onto !STREET!
	["c00t0d00"] = "在道路的終點 !NG_COMMAND_1! 請迴轉 進入 !STREET!",
	-- 270: and then take the ferry towards !STREET_2! !SIGNPOST_2!
	["h00m000x"] = "然後 請上渡船 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 271: and then take the ferry !NG_COMMAND_2! towards !STREET!
	["h000mc00"] = "然後 !NG_COMMAND_2! 請上渡船 !BREAK:200! 往 !STREET!",
	-- 272: and then you will reach your destination !NG_COMMAND_2!
	["h000a000"] = "然後 !NG_COMMAND_2! 您即將到達目的地",
	-- 273: and then take the exit !NG_COMMAND_2! towards !STREET!
	["h000dc00"] = "然後 !NG_COMMAND_2! 請從出口離開 !BREAK:200! 往 !STREET!",
	-- 274: and then keep right !NG_COMMAND_2! towards !SIGNPOST!
	["h00p00c0"] = "然後 !NG_COMMAND_2! 請保持右側行駛 !BREAK:200! 往 !SIGNPOST!",
	-- 275: and then immediately turn slightly right !NG_COMMAND_2! towards !SIGNPOST!
	["j00q00c0"] = "然後 !NG_COMMAND_2! 立即 請小幅度右轉 !BREAK:200! 往 !SIGNPOST!",
	-- 276: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the motorway
	["bl0wf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路,",
	-- 277: and then immediately go straight ahead !NG_COMMAND_2!
	["j00n0000"] = "然後 !NG_COMMAND_2! 立即 請直走",
	-- 278: and then immediately make a u turn !NG_COMMAND_2! towards !SIGNPOST!
	["j00t00c0"] = "然後 !NG_COMMAND_2! 立即 請迴轉 !BREAK:200! 往 !SIGNPOST!",
	-- 279: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0siac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 280: Follow the course of the road for !DIST! !UNIT!
	["el000000"] = "請繼續順著前方道路行駛 !DIST! !UNIT!",
	-- 281: Follow the motorway !STREET! for !DIST! !UNIT!
	["d0000000"] = "請順著高速公路 !STREET! 行駛 !DIST! !UNIT!",
	-- 282: and then immediately keep right !NG_COMMAND_2! towards !SIGNPOST!
	["j00p00c0"] = "然後 !NG_COMMAND_2! 立即 請保持右側行駛 !BREAK:200! 往 !SIGNPOST!",
	-- 283: and then immediately keep left !NG_COMMAND_2! towards !SIGNPOST!
	["j00x00c0"] = "然後 !NG_COMMAND_2! 立即 請保持左側行駛 !BREAK:200! 往 !SIGNPOST!",
	-- 284: and then enter the motorway !STREET! towards !SIGNPOST!
	["h00f0ac0"] = "然後 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 285: and then immediately turn sharply right !NG_COMMAND_2! towards !SIGNPOST!
	["j00s00c0"] = "然後 !NG_COMMAND_2! 立即 請向右急轉彎 !BREAK:200! 往 !SIGNPOST!",
	-- 286: and then immediately turn slightly left !NG_COMMAND_2! towards !SIGNPOST!
	["j00w00c0"] = "然後 !NG_COMMAND_2! 立即 請小幅度左轉 !BREAK:200! 往 !SIGNPOST!",
	-- 287: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0n0edz"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 288: and then immediately turn left !NG_COMMAND_2! towards !SIGNPOST!
	["j00v00c0"] = "然後 !NG_COMMAND_2! 立即 請向左轉 !BREAK:200! 往 !SIGNPOST!",
	-- 289: and then immediately enter the urban motorway !NG_COMMAND_2! towards !SIGNPOST!
	["j000i0c0"] = "然後 !NG_COMMAND_2! 立即 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!",
	-- 290: and then immediately enter the motorway !NG_COMMAND_2! towards !SIGNPOST!
	["j000f0c0"] = "然後 !NG_COMMAND_2! 立即 進入高速公路 !BREAK:200! 往 !SIGNPOST!",
	-- 291: and then take the second left !NG_COMMAND_2!
	["h00z0000"] = "然後 !NG_COMMAND_2! 請從第二個路口左轉",
	-- 292: At the end of the road turn slightly left !NG_COMMAND_1! towards !STREET!
	["c00w0c00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉 !BREAK:200! 往 !STREET!",
	-- 293: and then immediately take the second left !NG_COMMAND_2!
	["j00z0000"] = "然後 !NG_COMMAND_2! 立即 請從第二個路口左轉",
	-- 294: Now keep left !NG_COMMAND_1! enter the urban motorway
	["a00xi000"] = "現在 !NG_COMMAND_1! 請保持左側行駛, 進入市區快速道路,",
	-- 295: and then immediately take the ferry !NG_COMMAND_2!
	["j000m000"] = "然後 !NG_COMMAND_2! 立即 請上渡船",
	-- 296: After !DIST! !UNIT! turn right !NG_COMMAND_1! onto !STREET!
	["bl0r0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 進入 !STREET!",
	-- 297: and then turn slightly left !NG_COMMAND_2! towards !STREET!
	["h00w0c00"] = "然後 !NG_COMMAND_2! 請小幅度左轉 !BREAK:200! 往 !STREET!",
	-- 298: and then immediately take the exit !NG_COMMAND_2!
	["j000d000"] = "然後 !NG_COMMAND_2! 立即 請從出口離開",
	-- 299: and then keep left !NG_COMMAND_2! towards !SIGNPOST!
	["h00x00c0"] = "然後 !NG_COMMAND_2! 請保持左側行駛 !BREAK:200! 往 !SIGNPOST!",
	-- 300: and then immediately take the ferry !NG_COMMAND_2! towards !STREET!
	["j000mc00"] = "然後 !NG_COMMAND_2! 立即 請上渡船 !BREAK:200! 往 !STREET!",
	-- 301: and then take the exit !NG_COMMAND_2!
	["h000j000"] = "然後 !NG_COMMAND_2! 請從出口離開",
	-- 302: and then immediately take the exit !NG_COMMAND_2! onto !STREET!
	["j000dd00"] = "然後 !NG_COMMAND_2! 立即 請從出口離開 進入 !STREET!",
	-- 303: and then immediately take the exit !NG_COMMAND_2!
	["j000j000"] = "然後 !NG_COMMAND_2! 立即 請從出口離開",
	-- 304: After !DIST! !UNIT! turn left !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0vfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入高速公路 !STREET!,",
	-- 305: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the urban motorway
	["bl0ni000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入市區快速道路,",
	-- 306: and then go straight ahead !NG_COMMAND_2!
	["h00n0000"] = "然後 !NG_COMMAND_2! 請直走",
	-- 307: After the junction keep left !NG_COMMAND_1!
	["bz0x0000"] = "經過交叉口後 !NG_COMMAND_1! 請保持左側行駛",
	-- 308: drive to nearest road
	["000l0000"] = "請駛向最接近的道路",
	-- 309: and then immediately keep left !NG_COMMAND_2! towards !STREET!
	["j00x0c00"] = "然後 !NG_COMMAND_2! 立即 請保持左側行駛 !BREAK:200! 往 !STREET!",
	-- 310: and then immediately enter the motorway !STREET! towards !SIGNPOST!
	["j000fac0"] = "然後 立即 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 311: and then immediately enter the motorway !STREET!
	["j000fa00"] = "然後 立即 進入高速公路 !STREET!",
	-- 312: and then immediately take the second left !NG_COMMAND_2! towards !STREET!
	["j00z0c00"] = "然後 !NG_COMMAND_2! 立即 請從第二個路口左轉 !BREAK:200! 往 !STREET!",
	-- 313: Now go straight ahead !NG_COMMAND_1!
	["a00n0000"] = "現在 !NG_COMMAND_1! 請直走",
	-- 314: and then immediately turn slightly left !NG_COMMAND_2! towards !STREET!
	["j00w0c00"] = "然後 !NG_COMMAND_2! 立即 請小幅度左轉 !BREAK:200! 往 !STREET!",
	-- 315: and then immediately take the second left , !STREET!
	["j00z0a00"] = "然後 立即 請從第二個路口左轉 !STREET!",
	-- 316: and then immediately make a u turn, !STREET! towards !SIGNPOST!
	["j00t0ac0"] = "然後 立即 請迴轉 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 317: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! towards !STREET!
	["bl0u0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 !BREAK:200! 往 !STREET!",
	-- 318: and then immediately keep right, !STREET! towards !SIGNPOST!
	["j00p0ac0"] = "然後 立即 請保持右側行駛 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 319: and then immediately turn left, !STREET! towards !SIGNPOST!
	["j00v0ac0"] = "然後 在 !STREET! 立即 請向左轉!BREAK:200! 往 !SIGNPOST!",
	-- 320: and then immediately turn sharply left !NG_COMMAND_2! onto !STREET!
	["j00u0d00"] = "然後 !NG_COMMAND_2! 立即 請向左急轉彎 進入 !STREET!",
	-- 321: and then immediately go straight ahead !NG_COMMAND_2! towards !STREET!
	["j00n0c00"] = "然後 !NG_COMMAND_2! 立即 請直走 !BREAK:200! 往 !STREET!",
	-- 322: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0tfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 323: At the end of the road make a u turn !NG_COMMAND_1! , enter the urban motorway
	["c00ti000"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入市區快速道路,",
	-- 324: After !DIST! !UNIT! turn left !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0vfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 325: At the end of the road turn sharply left !NG_COMMAND_1! onto !STREET!
	["c00u0d00"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎 進入 !STREET!",
	-- 326: and then take the second left !NG_COMMAND_2! towards !STREET!
	["h00z0c00"] = "然後 !NG_COMMAND_2! 請從第二個路口左轉 !BREAK:200! 往 !STREET!",
	-- 327: and then immediately turn slightly right !NG_COMMAND_2!
	["j00q0000"] = "然後 !NG_COMMAND_2! 立即 請小幅度右轉",
	-- 328: and then go straight ahead !NG_COMMAND_2! towards !SIGNPOST!
	["h00n00c0"] = "然後 !NG_COMMAND_2! 請直走 !BREAK:200! 往 !SIGNPOST!",
	-- 329: After the junction turn right !NG_COMMAND_1!
	["bz0r0000"] = "經過交叉口後 !NG_COMMAND_1! 請向右轉",
	-- 330: and then immediately go straight ahead !NG_COMMAND_2! towards !SIGNPOST!
	["j00n00c0"] = "然後 !NG_COMMAND_2! 立即 請直走 !SIGNPOST!",
	-- 331: and then immediately make a u turn !NG_COMMAND_2! onto !STREET!
	["j00t0d00"] = "然後 !NG_COMMAND_2! 立即 請迴轉 進入 !STREET!",
	-- 332: and then immediately make a u turn !NG_COMMAND_2!
	["j00t0000"] = "然後 !NG_COMMAND_2! 立即 請迴轉",
	-- 333: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER!
	["bl0p0e00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! 離開,",
	-- 334: and then immediately enter the urban motorway !STREET!
	["j000ia00"] = "然後 立即 進入市區快速道路 !STREET!",
	-- 335: and then keep left !NG_COMMAND_2! , !STREET! towards !SIGNPOST!
	["h00x0ac0"] = "然後 !NG_COMMAND_2! 請保持左側行駛 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 336: and then immediately turn right !NG_COMMAND_2! towards !STREET!
	["j00r0c00"] = "然後 !NG_COMMAND_2! 立即 請向右轉 !BREAK:200! 往 !STREET!",
	-- 337: and then immediately turn right !NG_COMMAND_2! onto !STREET!
	["j00r0d00"] = "然後 !NG_COMMAND_2! 立即 請向右轉 進入 !STREET!",
	-- 338: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0wia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路 !STREET!,",
	-- 339: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the urban motorway
	["bl0si000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 340: and then immediately turn right !NG_COMMAND_2! towards !SIGNPOST!
	["j00r00c0"] = "然後 !NG_COMMAND_2! 立即 請向右轉 !BREAK:200! 往 !SIGNPOST!",
	-- 341: and then immediately turn sharply right !NG_COMMAND_2! towards !STREET!
	["j00s0c00"] = "然後 !NG_COMMAND_2! 立即 請向右急轉彎 !BREAK:200! 往 !STREET!",
	-- 342: and then turn right !NG_COMMAND_2! towards !SIGNPOST!
	["h00r00c0"] = "然後 !NG_COMMAND_2! 請向右轉 !BREAK:200! 往 !SIGNPOST!",
	-- 343: and then enter the urban motorway !STREET!
	["h000ia00"] = "然後 進入市區快速道路 !STREET!",
	-- 344: Now keep left !NG_COMMAND_1! , enter the motorway
	["a00xf000"] = "現在 !NG_COMMAND_1! 請保持左側行駛, 進入高速公路,",
	-- 345: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the urban motorway
	["bl0ui000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路,",
	-- 346: and then immediately turn sharply right !NG_COMMAND_2!
	["j00s0000"] = "然後 !NG_COMMAND_2! 立即 請向右急轉彎",
	-- 347: and then immediately turn sharply left !NG_COMMAND_2! towards !STREET!
	["j00u0c00"] = "然後 !NG_COMMAND_2! 立即 請向左急轉彎 !BREAK:200! 往 !STREET!",
	-- 348: and then immediately turn sharply left !NG_COMMAND_2!
	["j00u0000"] = "然後 !NG_COMMAND_2! 立即 請向左急轉彎",
	-- 349: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! towards !STREET_2! !SIGNPOST_2!
	["bl0x0edx"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 350: and then immediately take the second right !NG_COMMAND_2! towards !STREET!
	["j00y0c00"] = "然後 !NG_COMMAND_2! 立即 請從第二個路口右轉 !BREAK:200! 往 !STREET!",
	-- 351: and then immediately turn slightly left !NG_COMMAND_2! onto !STREET!
	["j00w0d00"] = "然後 !NG_COMMAND_2! 立即 請小幅度左轉 進入 !STREET!",
	-- 352: and then take the second right !NG_COMMAND_2! towards !STREET!
	["h00y0c00"] = "然後 !NG_COMMAND_2! 請從第二個路口右轉 !BREAK:200! 往 !STREET!",
	-- 353: and then immediately turn left !NG_COMMAND_2! towards !STREET!
	["j00v0c00"] = "然後 !NG_COMMAND_2! 立即 請向左轉 !BREAK:200! 往 !STREET!",
	-- 354: and then immediately keep left, !STREET!
	["j00x0a00"] = "然後 立即 請保持左側行駛 !STREET!",
	-- 355: and then immediately take the middle lane !NG_COMMAND_2! towards !STREET!
	["j00o0c00"] = "然後 !NG_COMMAND_2! 立即 請走中間車道 !BREAK:200! 往 !STREET!",
	-- 356: After the junction take the middle lane !NG_COMMAND_1!
	["bz0o0000"] = "經過交叉口後 !NG_COMMAND_1! 請走中間車道",
	-- 357: and then immediately take the middle lane !NG_COMMAND_2! onto !STREET!
	["j00o0d00"] = "然後 !NG_COMMAND_2! 立即 請走中間車道 進入 !STREET!",
	-- 358: At the end of the road turn sharply left !NG_COMMAND_1!
	["c00u0000"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎",
	-- 359: and then turn sharply left !NG_COMMAND_2!
	["h00u0000"] = "然後 !NG_COMMAND_2! 請向左急轉彎",
	-- 360: and then immediately turn left !NG_COMMAND_2! onto !STREET!
	["j00v0d00"] = "然後 !NG_COMMAND_2! 立即 請向左轉 進入 !STREET!",
	-- 361: and then immediately make a u turn, !STREET!
	["j00t0a00"] = "然後 立即 請迴轉 !STREET!",
	-- 362: and then immediately keep right, !STREET!
	["j00p0a00"] = "然後 立即 請保持右側行駛 !STREET!",
	-- 363: and then immediately go straight ahead, !STREET! towards !SIGNPOST!
	["j00n0ac0"] = "然後 立即 請直走 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 364: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! and take the exit
	["bl0o00fg"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道 然後 請從出口離開",
	-- 365: and then immediately turn right, !STREET!
	["j00r0a00"] = "然後 立即 請向右轉 !STREET!",
	-- 366: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0rf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 367: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0xf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 368: Now turn sharply left !NG_COMMAND_1!
	["a00u0000"] = "現在 !NG_COMMAND_1! 請向左急轉彎",
	-- 369: At the end of the road turn left !NG_COMMAND_1! onto !STREET!
	["c00v0d00"] = "在道路的終點 !NG_COMMAND_1! 請向左轉 進入 !STREET!",
	-- 370: and then take the middle lane, !STREET! towards !SIGNPOST!
	["h00o0ac0"] = "然後 請走中間車道 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 371: After !DIST! !UNIT! take the exit !NG_COMMAND_1! towards !STREET!
	["bl0d0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請從出口離開 !BREAK:200! 往 !STREET!",
	-- 372: After !DIST! !UNIT! turn left !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0vi0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 373: and then immediately turn slightly left, !STREET!
	["j00w0a00"] = "然後 立即 請小幅度左轉 !STREET!",
	-- 374: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1!
	["bl0n0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走",
	-- 375: and then you will reach a stopover !NG_COMMAND_2! on !STREET!
	["h000bb00"] = "然後 !NG_COMMAND_2! 您即將 在 !STREET! 到達休息站",
	-- 376: and then go straight ahead, !STREET! towards !SIGNPOST!
	["h00n0ac0"] = "然後 請直走 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 377: At the end of the road turn slightly left !NG_COMMAND_1! , enter the motorway !STREET!
	["c00wfa00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路 !STREET!,",
	-- 378: and then keep left !NG_COMMAND_2!
	["h00x0000"] = "然後 !NG_COMMAND_2! 請保持左側行駛",
	-- 379: and then turn slightly right !NG_COMMAND_2!
	["h00q0000"] = "然後 !NG_COMMAND_2! 請小幅度右轉",
	-- 380: and then turn right !NG_COMMAND_2!
	["h00r0000"] = "然後 !NG_COMMAND_2! 請向右轉",
	-- 381: and then you will reach your destination !NG_COMMAND_2!
	["h00a0000"] = "然後 !NG_COMMAND_2! 您即將到達目的地",
	-- 382: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0o000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 383: and then take the exit !NG_COMMAND_2! towards !STREET!
	["h000jc00"] = "然後 !NG_COMMAND_2! 請從出口離開 !BREAK:200! 往 !STREET!",
	-- 384: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the motorway
	["bl0qf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路,",
	-- 385: and then keep left !NG_COMMAND_2! onto !STREET!
	["h00x0d00"] = "然後 !NG_COMMAND_2! 請保持左側行駛 請從出口離開 進入 !STREET!",
	-- 386: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take the exit
	["bl0n000g"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口離開,",
	-- 387: and then take the exit !NG_COMMAND_2! onto !STREET!
	["h000gd00"] = "然後 !NG_COMMAND_2! 請從出口離開 進入 !STREET!",
	-- 388: and then turn slightly left !NG_COMMAND_2! onto !STREET!
	["h00w0d00"] = "然後 !NG_COMMAND_2! 請小幅度左轉 請從出口離開 進入 !STREET!",
	-- 389: and then turn sharply right !NG_COMMAND_2! onto !STREET!
	["h00s0d00"] = "然後 !NG_COMMAND_2! 請向右急轉彎 請從出口離開 進入 !STREET!",
	-- 390: Now take the middle lane !NG_COMMAND_1! and take the exit
	["a00o00fg"] = "現在 !NG_COMMAND_1! 請走中間車道 然後 請從出口離開",
	-- 391: and then take the exit !NG_COMMAND_2! onto !STREET!
	["h000jd00"] = "然後 !NG_COMMAND_2! 請從出口離開 進入 !STREET!",
	-- 392: At the end of the road turn right !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["c00rfac0"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 393: and then go straight ahead !NG_COMMAND_2! onto !STREET!
	["h00n0d00"] = "然後 !NG_COMMAND_2! 請直走 進入 !STREET!",
	-- 394: At the end of the road turn left !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["c00v000x"] = "在道路的終點 !NG_COMMAND_1! 請向左轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 395: and then go straight ahead !NG_COMMAND_2! towards !STREET!
	["h00n0c00"] = "然後 !NG_COMMAND_2! 請直走 !BREAK:200! 往 !STREET!",
	-- 396: and then make a u turn !NG_COMMAND_2! onto !STREET!
	["h00t0d00"] = "然後 !NG_COMMAND_2! 請迴轉 進入 !STREET!",
	-- 397: After !DIST! !UNIT! turn left !NG_COMMAND_1! enter the motorway
	["bl0vf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入高速公路,",
	-- 398: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0pf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 399: and then turn sharply left !NG_COMMAND_2! onto !STREET!
	["h00u0d00"] = "然後 !NG_COMMAND_2! 請向左急轉彎 進入 !STREET!",
	-- 400: and then turn sharply left !NG_COMMAND_2! towards !STREET!
	["h00u0c00"] = "然後 !NG_COMMAND_2! 請向左急轉彎 !BREAK:200! 往 !STREET!",
	-- 401: and then turn left !NG_COMMAND_2! onto !STREET!
	["h00v0d00"] = "然後 !NG_COMMAND_2! 請向左轉 進入 !STREET!",
	-- 402: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0nfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入高速公路 !STREET!,",
	-- 403: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0ria00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入市區快速道路 !STREET!,",
	-- 404: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the motorway
	["bl0of000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入高速公路,",
	-- 405: and then keep right !NG_COMMAND_2! onto !STREET!
	["h00p0d00"] = "然後 !NG_COMMAND_2! 請保持右側行駛 進入 !STREET!",
	-- 406: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! onto !STREET!
	["bl0n0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 進入 !STREET!",
	-- 407: and then keep right !NG_COMMAND_2! towards !STREET!
	["h00p0c00"] = "然後 !NG_COMMAND_2! 請保持右側行駛 !BREAK:200! 往 !STREET!",
	-- 408: and then turn slightly right !NG_COMMAND_2! onto !STREET!
	["h00q0d00"] = "然後 !NG_COMMAND_2! 請小幅度右轉 進入 !STREET!",
	-- 409: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take exit !EXIT_NUMBER! towards !STREET_2! !SIGNPOST_2!
	["bl0n0e0x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 410: At the end of the road turn right !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["c00rf0c0"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 411: and then turn sharply right !NG_COMMAND_2! towards !STREET!
	["h00s0c00"] = "然後 !NG_COMMAND_2! 請向右急轉彎 !BREAK:200! 往 !STREET!",
	-- 412: and then turn right !NG_COMMAND_2! onto !STREET!
	["h00r0d00"] = "然後 !NG_COMMAND_2! 請向右轉 進入 !STREET!",
	-- 413: After !DIST! !UNIT! turn left !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0vf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 414: At the end of the road turn slightly left !NG_COMMAND_1! , enter the motorway
	["c00wf000"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路,",
	-- 415: and then enter the urban motorway !STREET! towards !SIGNPOST!
	["h000iac0"] = "然後 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 416: Now keep left !NG_COMMAND_1!
	["a00x0000"] = "現在 !NG_COMMAND_1! 請保持左側行駛",
	-- 417: At the end of the road turn slightly left !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["c00wiac0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 418: and then enter the motorway !NG_COMMAND_2! towards !SIGNPOST!
	["h000f0c0"] = "然後 !NG_COMMAND_2! 進入高速公路 !BREAK:200! 往 !SIGNPOST!",
	-- 419: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0xi0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 420: At the end of the road turn right !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["c00ri0c0"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 421: and then enter the motorway !STREET!
	["h000fa00"] = "然後 進入高速公路 !STREET!",
	-- 422: and then go straight ahead, !STREET!
	["h00n0a00"] = "然後 請直走 !STREET!",
	-- 423: and then immediately keep left !NG_COMMAND_2!
	["j00x0000"] = "然後 !NG_COMMAND_2! 立即 請保持左側行駛",
	-- 424: At the end of the road turn slightly left !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["c00w000x"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 425: and then make a u turn, !STREET! towards !SIGNPOST!
	["h00t0ac0"] = "然後 請迴轉 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 426: and then take the middle lane !NG_COMMAND_2! towards !SIGNPOST!
	["h00o00c0"] = "然後 !NG_COMMAND_2! 請走中間車道 !BREAK:200! 往 !SIGNPOST!",
	-- 427: and then immediately turn sharply right, !STREET!
	["j00s0a00"] = "然後 立即 請向右急轉彎 !STREET!",
	-- 428: At the end of the road turn sharply right !NG_COMMAND_1! , enter the urban motorway !STREET!
	["c00sia00"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路 !STREET!,",
	-- 429: and then keep left, !STREET!
	["h00x0a00"] = "然後 請保持左側行駛 !STREET!",
	-- 430: Now turn sharply right !NG_COMMAND_1! , enter the motorway
	["a00sf000"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路,",
	-- 431: and then make a u turn !NG_COMMAND_2! towards !SIGNPOST!
	["h00t00c0"] = "然後 !NG_COMMAND_2! 請迴轉 !BREAK:200! 往 !SIGNPOST!",
	-- 432: At the end of the road turn sharply right !NG_COMMAND_1! , enter the motorway
	["c00sf000"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路,",
	-- 433: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1!
	["bl0u0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎",
	-- 434: At the end of the road make a u turn !NG_COMMAND_1! , enter the urban motorway !STREET!
	["c00tia00"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入市區快速道路 !STREET!,",
	-- 435: and then turn slightly left !NG_COMMAND_2! towards !SIGNPOST!
	["h00w00c0"] = "然後 !NG_COMMAND_2! 請小幅度左轉 !BREAK:200! 往 !SIGNPOST!",
	-- 436: and then turn sharply left, !STREET!
	["h00u0a00"] = "然後 請向左急轉彎 !STREET!",
	-- 437: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take the exit
	["bl0o000g"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口離開,",
	-- 438: At the end of the road turn sharply right !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["c00si0c0"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 439: At the end of the road turn right !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["c00riac0"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 440: and then turn slightly right !NG_COMMAND_2! towards !SIGNPOST!
	["h00q00c0"] = "然後 !NG_COMMAND_2! 請小幅度右轉 !BREAK:200! 往 !SIGNPOST!",
	-- 441: and then turn sharply right, !STREET!
	["h00s0a00"] = "然後 請向右急轉彎 !STREET!",
	-- 442: After !DIST! !UNIT! turn left !NG_COMMAND_1!
	["bl0v0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉",
	-- 443: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0o0e0z"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛!BREAK:200! 往 !SIGNPOST_2!",
	-- 444: and then turn sharply right, !STREET! towards !SIGNPOST!
	["h00s0ac0"] = "然後 在 !STREET! 請向右急轉彎 !BREAK:200! 往 !SIGNPOST!",
	-- 445: and then turn right onto !STREET! towards !SIGNPOST!
	["h00r0ac0"] = "然後 在 !STREET! 請向右轉 !BREAK:200! 往 !SIGNPOST!",
	-- 446: and then !EXIT_NO_ROUNDABOUT! at the roundabout onto !STREET!
	["h000czb0"] = "然後 請繞圓環行駛， !EXIT_NO_ROUNDABOUT! 進入 !STREET!",
	-- 447: and then take the exit !NG_COMMAND_2!
	["h00j0000"] = "然後 !NG_COMMAND_2! 請從出口離開",
	-- 448: and then !EXIT_NO_ROUNDABOUT! at the roundabout
	["h00c0z00"] = "然後 請繞圓環行駛， !EXIT_NO_ROUNDABOUT!",
	-- 449: After !DIST! !UNIT! keep left !NG_COMMAND_1! towards !STREET!
	["bl0x0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛 !BREAK:200! 往 !STREET!",
	-- 450: After !DIST! !UNIT! keep left !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0x000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 451: After !DIST! !UNIT! turn left !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0v000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 452: After the junction make a u turn !NG_COMMAND_1!
	["bz0t0000"] = "經過交叉口後 !NG_COMMAND_1! 請迴轉",
	-- 453: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0pfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入高速公路 !STREET!,",
	-- 454: and then enter the motorway !NG_COMMAND_2!
	["h00f0000"] = "然後 !NG_COMMAND_2! 進入高速公路",
	-- 455: After !DIST! !UNIT! you will reach your destination !NG_COMMAND_1!
	["bl0a0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 您即將到達目的地",
	-- 456: and then take the exit !NG_COMMAND_2! onto !STREET!
	["h000dd00"] = "然後 !NG_COMMAND_2! 請從出口離開 進入 !STREET!",
	-- 457: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["bl0wf0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 458: and then !EXIT_NO_ROUNDABOUT! at the roundabout
	["h000cz00"] = "然後 請繞圓環行駛， !EXIT_NO_ROUNDABOUT!",
	-- 459: and then take the ferry !NG_COMMAND_2!
	["h000m000"] = "然後 !NG_COMMAND_2! 請上渡船",
	-- 460: and then enter the urban motorway !STREET!
	["h00i0a00"] = "然後 進入市區快速道路 !STREET!",
	-- 461: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the urban motorway
	["bl0xi000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入市區快速道路,",
	-- 462: and then enter the motorway towards !SIGNPOST!
	["h00f00c0"] = "然後 進入高速公路 !BREAK:200! 往 !SIGNPOST!",
	-- 463: and then enter the motorway !STREET!
	["h00f0a00"] = "然後 進入高速公路 !STREET!",
	-- 464: and then immediately turn right !NG_COMMAND_2!
	["j00r0000"] = "然後 !NG_COMMAND_2! 立即 請向右轉",
	-- 465: Now keep left !NG_COMMAND_1! and take the exit
	["a00x00fg"] = "現在 !NG_COMMAND_1! 請保持左側行駛 然後 請從出口離開",
	-- 466: After !DIST! !UNIT! turn right !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0r000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 467: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! towards !STREET!
	["bl0o0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道 !BREAK:200! 往 !STREET!",
	-- 468: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take the exit
	["bl0x000g"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口離開,",
	-- 469: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take the exit
	["bl0p000g"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口離開,",
	-- 470: and then make a u turn, !STREET!
	["h00t0a00"] = "然後 請迴轉 !STREET!",
	-- 471: Now turn right !NG_COMMAND_1!
	["a00r0000"] = "現在 !NG_COMMAND_1! 請向右轉",
	-- 472: and then turn left !NG_COMMAND_2! towards !SIGNPOST!
	["h00v00c0"] = "然後 !NG_COMMAND_2! 請向左轉 !BREAK:200! 往 !SIGNPOST!",
	-- 473: At the end of the road turn right !NG_COMMAND_1!
	["c00r0000"] = "在道路的終點 !NG_COMMAND_1! 請向右轉",
	-- 474: After !DIST! !UNIT! keep right !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0p000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 475: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0s000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 476: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0u000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 477: At the end of the road turn slightly right !NG_COMMAND_1! , enter the motorway !STREET!
	["c00qfa00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路 !STREET!,",
	-- 478: After !DIST! !UNIT! keep left !NG_COMMAND_1! onto !STREET!
	["bl0x0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛 進入 !STREET!",
	-- 479: and then enter the urban motorway !NG_COMMAND_2!
	["h00i0000"] = "然後 !NG_COMMAND_2! 進入市區快速道路",
	-- 480: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take exit !EXIT_NUMBER! and continue on !STREET_2!
	["bl0n0e0y"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛",
	-- 481: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0rfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入高速公路 !STREET!,",
	-- 482: After !DIST! !UNIT! enter the urban motorway !STREET! towards !SIGNPOST!
	["bl00iac0"] = "!DIST! !UNIT! 之後 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 483: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0xiac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 484: Now turn slightly left !NG_COMMAND_1! , enter the urban motorway
	["a00wi000"] = "現在 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路,",
	-- 485: After !DIST! !UNIT! keep left !NG_COMMAND_1! take exit !EXIT_NUMBER! and continue on !STREET_2!
	["bl0x0e0y"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛",
	-- 486: At the end of the road turn left !NG_COMMAND_1! , enter the motorway
	["c00vf000"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入高速公路,",
	-- 487: At the end of the road turn sharply right !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["c00sf0c0"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 488: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["bl0w000x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 489: and then !EXIT_NO_ROUNDABOUT! at the roundabout towards !SIGNPOST!
	["h000czc0"] = "然後 請繞圓環行駛， !EXIT_NO_ROUNDABOUT! !BREAK:200! 往 !SIGNPOST!",
	-- 490: At the end of the road turn sharply left !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["c00uiac0"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 491: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take exit !EXIT_NUMBER!
	["bl0x0e00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! 離開,",
	-- 492: and then immediately keep right !NG_COMMAND_2! towards !STREET!
	["j00p0c00"] = "然後 !NG_COMMAND_2! 立即 請保持右側行駛 !BREAK:200! 往 !STREET!",
	-- 493: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0p0e0z"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 494: After !DIST! !UNIT! take exit !EXIT_NUMBER! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl000e0z"] = "!DIST! !UNIT! 之後, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 495: After !DIST! !UNIT! take exit !EXIT_NUMBER!
	["bl000e00"] = "!DIST! !UNIT! 之後 請從出口 !EXIT_NUMBER! 離開",
	-- 496: After !DIST! !UNIT! take the exit !NG_COMMAND_1!
	["bl00000g"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請從出口離開",
	-- 497: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0sfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路 !STREET!,",
	-- 498: Now keep right !NG_COMMAND_1! , take the exit
	["a00p000g"] = "現在 !NG_COMMAND_1! 請保持右側行駛, 請從出口離開,",
	-- 499: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! onto !STREET!
	["bl0u0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 進入 !STREET!",
	-- 500: Now take the middle lane !NG_COMMAND_1! , enter the urban motorway
	["a00oi000"] = "現在 !NG_COMMAND_1! 請走中間車道, 進入市區快速道路,",
	-- 501: After !DIST! !UNIT! keep right !NG_COMMAND_1! onto !STREET!
	["bl0p0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛 進入 !STREET!",
	-- 502: After !DIST! !UNIT! make a u turn !NG_COMMAND_1!
	["bl0t0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉",
	-- 503: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0ufa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路 !STREET!,",
	-- 504: At the end of the road turn left !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["c00vfac0"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 505: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0qia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路 !STREET!,",
	-- 506: Now keep right !NG_COMMAND_1! enter the motorway
	["a00pf000"] = "現在 !NG_COMMAND_1! 請保持右側行駛, 進入高速公路,",
	-- 507: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take exit !EXIT_NUMBER! towards !STREET_2! !SIGNPOST_2!
	["bl0x0e0x"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 508: and then immediately enter the urban motorway !STREET! towards !SIGNPOST!
	["j000iac0"] = "然後 立即 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 509: and then immediately turn sharply right !NG_COMMAND_2! onto !STREET!
	["j00s0d00"] = "然後 !NG_COMMAND_2! 立即 請向右急轉彎 進入 !STREET!",
	-- 510: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER! and continue on !STREET_2!
	["bl0p0e0y"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛",
	-- 511: Now turn slightly left !NG_COMMAND_1! , enter the motorway
	["a00wf000"] = "現在 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路,",
	-- 512: Now turn left !NG_COMMAND_1! , enter the motorway
	["a00vf000"] = "現在 !NG_COMMAND_1! 請向左轉, 進入高速公路,",
	-- 513: Now take the middle lane !NG_COMMAND_1! , take the exit
	["a00o000g"] = "現在 !NG_COMMAND_1! 請走中間車道, 請從出口離開,",
	-- 514: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0ui0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 515: At the end of the road turn sharply right !NG_COMMAND_1! onto !STREET!
	["c00s0d00"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎 進入 !STREET!",
	-- 516: Now take the middle lane !NG_COMMAND_1! enter the motorway
	["a00of000"] = "現在 !NG_COMMAND_1! 請走中間車道, 進入高速公路,",
	-- 517: At the end of the road make a u turn !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["c00tiac0"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 518: At the end of the road make a u turn !NG_COMMAND_1! towards !STREET!
	["c00t0c00"] = "在道路的終點 !NG_COMMAND_1! 請迴轉 !BREAK:200! 往 !STREET!",
	-- 519: At the end of the road make a u turn !NG_COMMAND_1! enter the motorway !STREET! towards !SIGNPOST!
	["c00tfac0"] = "在道路的終點 !NG_COMMAND_1! 請迴轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 520: Now turn slightly right !NG_COMMAND_1! , enter the motorway
	["a00qf000"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路,",
	-- 521: At the end of the road turn slightly right !NG_COMMAND_1! onto !STREET!
	["c00q0d00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉 進入 !STREET!",
	-- 522: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0niac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 523: At the end of the road turn left !NG_COMMAND_1! towards !STREET!
	["c00v0c00"] = "在道路的終點 !NG_COMMAND_1! 請向左轉 !BREAK:200! 往 !STREET!",
	-- 524: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0nia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入市區快速道路 !STREET!,",
	-- 525: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0tiac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 526: and then immediately make a u turn !NG_COMMAND_2! towards !STREET!
	["j00t0c00"] = "然後 !NG_COMMAND_2! 立即 請迴轉 !BREAK:200! 往 !STREET!",
	-- 527: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0pi0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 528: and then make a u turn !NG_COMMAND_2! towards !STREET!
	["h00t0c00"] = "然後 !NG_COMMAND_2! 請迴轉 !BREAK:200! 往 !STREET!",
	-- 529: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST!
	["bl0o0ed0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開,",
	-- 530: and then turn left !NG_COMMAND_2! towards !STREET!
	["h00v0c00"] = "然後 !NG_COMMAND_2! 請向左轉 !BREAK:200! 往 !STREET!",
	-- 531: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0ri0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 532: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0sfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 533: At the end of the road turn sharply left !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["c00u000x"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 534: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0wiac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 535: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0wi0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 536: After !DIST! !UNIT! turn left !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0viac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 537: After !DIST! !UNIT! turn left !NG_COMMAND_1! , enter the urban motorway
	["bl0vi000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 進入市區快速道路,",
	-- 538: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0oiac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 539: After !DIST! !UNIT! keep right !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! towards !STREET_2! !SIGNPOST_2!
	["bl0p0edx"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 540: After !DIST! !UNIT! take the ferry !NG_COMMAND_1! towards !STREET!
	["bl0m0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請上渡船 !BREAK:200! 往 !STREET!",
	-- 541: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , enter the urban motorway
	["bl0oi000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 進入市區快速道路,",
	-- 542: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the motorway !STREET!
	["bl0qfa00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路 !STREET!,",
	-- 543: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0nfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 544: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the motorway
	["bl0pf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入高速公路,",
	-- 545: After !DIST! !UNIT! keep left !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0xfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 546: After !DIST! !UNIT! turn right !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0rfac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 547: Now make a u turn !NG_COMMAND_1!
	["a00t0000"] = "現在 !NG_COMMAND_1! 請迴轉",
	-- 548: At the end of the road turn slightly right !NG_COMMAND_1! , enter the urban motorway
	["c00qi000"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路,",
	-- 549: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["bl0ufac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 550: Now turn slightly right !NG_COMMAND_1! , enter the urban motorway
	["a00qi000"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路,",
	-- 551: and then turn right !NG_COMMAND_2! towards !STREET!
	["h00r0c00"] = "然後 !NG_COMMAND_2! 請向右轉 !BREAK:200! 往 !STREET!",
	-- 552: After !DIST! !UNIT! keep right !NG_COMMAND_1! towards !STREET!
	["bl0p0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛 !BREAK:200! 往 !STREET!",
	-- 553: After !DIST! !UNIT! keep right !NG_COMMAND_1! , enter the urban motorway
	["bl0pi000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 進入市區快速道路,",
	-- 554: At the end of the road make a u turn !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["c00t000x"] = "在道路的終點 !NG_COMMAND_1! 請迴轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 555: At the end of the road turn right !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["c00r000x"] = "在道路的終點 !NG_COMMAND_1! 請向右轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 556: At the end of the road turn sharply right !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["c00s000x"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 557: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! , take exit !EXIT_NUMBER! and continue on !STREET_2!
	["bl0o0e0y"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛",
	-- 558: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the motorway
	["bl0uf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路,",
	-- 559: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0uia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 560: At the end of the road turn sharply left !NG_COMMAND_1! , enter the urban motorway
	["c00ui000"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路,",
	-- 561: Now turn sharply left !NG_COMMAND_1! , enter the urban motorway
	["a00ui000"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 進入市區快速道路,",
	-- 562: and then you will reach a stopover !NG_COMMAND_2!
	["h00b0000"] = "然後 !NG_COMMAND_2! 您即將到達休息站",
	-- 563: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the urban motorway !STREET! towards !SIGNPOST!
	["bl0qiac0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 564: At the end of the road turn right !NG_COMMAND_1! , enter the urban motorway !STREET!
	["c00ria00"] = "在道路的終點 !NG_COMMAND_1! 請向右轉, 進入市區快速道路 !STREET!,",
	-- 565: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! towards !STREET!
	["bl0n0c00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 !BREAK:200! 往 !STREET!",
	-- 566: At the end of the road turn right !NG_COMMAND_1! towards !STREET!
	["c00r0c00"] = "在道路的終點 !NG_COMMAND_1! 請向右轉 !BREAK:200! 往 !STREET!",
	-- 567: At the end of the road turn left !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["c00vi0c0"] = "在道路的終點 !NG_COMMAND_1! 請向左轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 568: and then keep right, !STREET! towards !SIGNPOST!
	["h00p0ac0"] = "然後 請保持右側行駛 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 569: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! onto !STREET!
	["bl0t0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉 進入 !STREET!",
	-- 570: and then immediately turn slightly right !NG_COMMAND_2! towards !STREET!
	["j00q0c00"] = "然後 !NG_COMMAND_2! 立即 請小幅度右轉 !BREAK:200! 往 !STREET!",
	-- 571: At the end of the road turn sharply left !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["c00ufac0"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 572: At the end of the road turn sharply right !NG_COMMAND_1! , enter the motorway !STREET! towards !SIGNPOST!
	["c00sfac0"] = "在道路的終點 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路 !STREET! !BREAK:200! 往 !SIGNPOST!,",
	-- 573: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take exit !EXIT_NUMBER!
	["bl0n0e00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! 離開,",
	-- 574: At the end of the road you will reach your destination !NG_COMMAND_1! on !STREET!
	["c00a0b00"] = "在道路的終點 !NG_COMMAND_1! 您即將 到達目的地 !STREET! ",
	-- 575: At the end of the road turn slightly right !NG_COMMAND_1! towards !STREET_2! !SIGNPOST_2!
	["c00q000x"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!",
	-- 576: At the end of the road turn slightly right !NG_COMMAND_1! towards !STREET!
	["c00q0c00"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉 !BREAK:200! 往 !STREET!",
	-- 577: After !DIST! !UNIT! keep left !NG_COMMAND_1!
	["bl0x0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛",
	-- 578: At the end of the road turn sharply left !NG_COMMAND_1! enter the motorway towards !SIGNPOST!
	["c00uf0c0"] = "在道路的終點 !NG_COMMAND_1! 請向左急轉彎, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 579: and then immediately go straight ahead !NG_COMMAND_2! onto !STREET!
	["j00n0d00"] = "然後 !NG_COMMAND_2! 立即 請直走 進入 !STREET!",
	-- 580: and then enter the urban motorway !NG_COMMAND_2! towards !SIGNPOST!
	["h000i0c0"] = "然後 !NG_COMMAND_2! 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!",
	-- 581: At the end of the road turn slightly right !NG_COMMAND_1! , enter the motorway
	["c00qf000"] = "在道路的終點 !NG_COMMAND_1! 請小幅度右轉, 進入高速公路,",
	-- 582: and then turn slightly right !NG_COMMAND_2! towards !STREET!
	["h00q0c00"] = "然後 !NG_COMMAND_2! 請小幅度右轉 !BREAK:200! 往 !STREET!",
	-- 583: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take exit !EXIT_NUMBER! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0n0e0z"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! 離開, 然後請繼續在 !STREET_2! 行駛 !BREAK:200! 往 !SIGNPOST_2!",
	-- 584: After !DIST! !UNIT! take the exit !NG_COMMAND_1!
	["bl0d0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請從出口離開",
	-- 585: Traffic on route, detouring
	["s0000000"] = "路線上有交通堵塞 正在繞行",
	-- 586: After the junction turn sharply left !NG_COMMAND_1!
	["bz0u0000"] = "經過交叉口後 !NG_COMMAND_1! 請向左急轉彎",
	-- 587: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the motorway
	["bl0sf000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入高速公路,",
	-- 588: At the end of the road turn slightly left !NG_COMMAND_1! , enter the motorway towards !SIGNPOST!
	["c00wf0c0"] = "在道路的終點 !NG_COMMAND_1! 請小幅度左轉, 進入高速公路 !BREAK:200! 往 !SIGNPOST!,",
	-- 589: After the junction turn slightly right !NG_COMMAND_1!
	["bz0q0000"] = "經過交叉口後 !NG_COMMAND_1! 請小幅度右轉",
	-- 590: Now make a u turn !NG_COMMAND_1!
	["a00e0000"] = "現在 !NG_COMMAND_1! 請迴轉",
	-- 591: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0sia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 進入市區快速道路 !STREET!,",
	-- 592: After !DIST! !UNIT! keep left !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2!
	["bl0x0edy"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開, 然後請繼續 在 !STREET_2! 行駛",
	-- 593: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! , enter the urban motorway !STREET!
	["bl0tia00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉, 進入市區快速道路 !STREET!,",
	-- 594: After !DIST! !UNIT! go straight ahead !NG_COMMAND_1! , take exit !EXIT_NUMBER! !SIGNPOST! towards !STREET_2! !SIGNPOST_2!
	["bl0n0edx"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請從出口 !EXIT_NUMBER! !SIGNPOST! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2!,",
	-- 595: After !DIST! !UNIT! keep right !NG_COMMAND_1!
	["bl0p0000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛",
	-- 596: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! onto !STREET!
	["bl0o0d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間車道 進入 !STREET!",
	-- 597: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , enter the urban motorway towards !SIGNPOST!
	["bl0qi0c0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 進入市區快速道路 !BREAK:200! 往 !SIGNPOST!,",
	-- 598: and then immediately turn sharply left onto !STREET!
	["j00u0a00"] = "然後 立即 請向左急轉彎 !STREET!",
	-- 603: After !DIST! !UNIT! make a u turn !NG_COMMAND_1!
	["blt00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉",
	-- 614: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! onto !STREET!
	["blt00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉 進入 !STREET!",
	-- 615: After !DIST! !UNIT! make a u turn !NG_COMMAND_1! and continue on !STREET!
	["blt00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉 然後請繼續在 !STREET! 行走",
	-- 621: Now make a u turn !NG_COMMAND_1! onto !STREET!
	["a0t00d00"] = "現在 !NG_COMMAND_1! 請迴轉 進入 !STREET!",
	-- 630: Now make a u turn !NG_COMMAND_1! and continue on !STREET!
	["a0t00f00"] = "現在 !NG_COMMAND_1! 請迴轉 然後請繼續 在 !STREET! 行走",
	-- 653: and then after !DIST! !UNIT! !NG_COMMAND_1! you will reach your destination
	["ll0a0000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 您即將到達目的地",
	-- 654: and then after !DIST! !UNIT! !NG_COMMAND_1! make a u turn
	["ll0e0000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉",
	-- 656: and then after !DIST! !UNIT! !NG_COMMAND_1! you will reach a stopover
	["ll0b0000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 您即將到達休息站",
	-- 668: and then after !DIST! !UNIT! !NG_COMMAND_1! make a u turn
	["llt00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請迴轉",
	-- 937: After !DIST! !UNIT! enter the highway !STREET!
	["bl00fa00"] = "!DIST! !UNIT! 之後 進入高速公路 !STREET!",
	-- 938: and then immediately keep left !NG_COMMAND_2! , !STREET! towards !SIGNPOST!
	["j00x0ac0"] = "然後 !NG_COMMAND_2! 立即 請保持左側行駛 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 939: After !DIST! !UNIT! take exit !EXIT_NUMBER! and continue on !STREET_2!
	["bl000e0y"] = "!DIST! !UNIT! 後，請從  !EXIT_NUMBER!  離開，然後繼續在 !STREET_2! 行駛",
	-- 940: After !DIST! !UNIT! take exit !EXIT_NUMBER! !SIGNPOST!
	["bl000ed0"] = "!DIST! !UNIT! 後，請從出口 !EXIT_NUMBER! !SIGNPOST! 離開",
	-- 941: After !DIST! !UNIT! take exit !EXIT_NUMBER! !SIGNPOST! towards !STREET_2! !SIGNPOST_2!
	["bl000edx"] = "!DIST! !UNIT! 之後，請從出口 !EXIT_NUMBER! !SIGNPOST! 離開 !BREAK:200! 往 !STREET_2! !SIGNPOST_2! 行駛",
	-- 942: After !DIST! !UNIT! take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl000edz"] = "!DIST! !UNIT! 之後，  請從出口 !EXIT_NUMBER! !SIGNPOST! 離開，然後繼續在 !STREET_2! !BREAK:200! 往 !SIGNPOST_2! 的方向行駛",
	-- 943: After !DIST! !UNIT! take exit !EXIT_NUMBER! !SIGNPOST! and continue on !STREET_2!
	["bl000edy"] = "!DIST! !UNIT! 後，  請從出口 !EXIT_NUMBER! !SIGNPOST! 離開，然後繼續在 !STREET_2! 行駛",
	-- 944: After !DIST! !UNIT! you will reach your destination !NG_COMMAND_1! . The destination is on your left
	["bl0a000l"] = "!DIST! !UNIT! 後，您將到達您的目的地 !NG_COMMAND_1! 您的目的地即在您的左邊",
	-- 945: After !DIST! !UNIT! you will reach your destination !NG_COMMAND_1! . The destination is on your right
	["bl0a000r"] = "!DIST! !UNIT! 後，您將到達您的目的地 !NG_COMMAND_1! 您的目的地即在您的右邊",
	-- 946: After !DIST! !UNIT! you will reach your destination !NG_COMMAND_1! on !STREET! . The destination is on your left
	["bl0a0b0l"] = "!DIST! !UNIT! 後，您將到達您在 !STREET! 的目的地 !NG_COMMAND_1! 您的目的地即在您的左邊",
	-- 947: After !DIST! !UNIT! you will reach your destination !NG_COMMAND_1! on !STREET! . The destination is on your right
	["bl0a0b0r"] = "!DIST! !UNIT! 後，您將到達您在 !STREET! 的目的地 !NG_COMMAND_1! 您的目的地即在您的右邊",
	-- 948: After !DIST! !UNIT! enter the motorway towards !SIGNPOST!
	["bl00f0c0"] = "!DIST! !UNIT! 後，請進入 !BREAK:200! 往 !SIGNPOST! 的快速道路",
	-- 949: After !DIST! !UNIT! enter the urban motorway towards !SIGNPOST!
	["bl00i0c0"] = "!DIST! !UNIT! 後，請進入 !BREAK:200! 往 !SIGNPOST! 的市區快速道路",
	-- 950: After !DIST! !UNIT! enter the urban motorway !STREET!
	["bl00ia00"] = "!DIST! !UNIT! 後，請進入 !BREAK:200! 往 !STREET! 的市區快速道路",
	-- 964: Enter the roundabout
	["000c0y00"] = "請進入圓環",
	-- 965: After !DIST! !UNIT! enter the roundabout
	["bl0c0y00"] = "!DIST! !UNIT! 之後， 請進入圓環",
	-- 966: At the end of the road enter the roundabout
	["c00c0y00"] = "在道路的終點，請進入圓環",
	-- 967: and then enter the roundabout
	["h000cy00"] = "然後進入圓環",
	-- 968: After !DIST! !UNIT! keep left !NG_COMMAND_1! and continue on !STREET_2!
	["bl0x000y"] = "!DIST! !UNIT! 之後， !NG_COMMAND_1! 請保持左側行駛， 接著請在 !STREET_2! 行駛",
	-- 969: After !DIST! !UNIT! keep left !NG_COMMAND_1! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0x000z"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持左側行駛, 接著在 !BREAK:200! 往 !SIGNPOST_2! 的 !STREET_2! 行駛",
	-- 970: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! and continue on !STREET_2!
	["bl0o000y"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 接著請在 !STREET_2! 行駛",
	-- 971: After !DIST! !UNIT! take the middle lane !NG_COMMAND_1! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0o000z"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 接著請在 !BREAK:200! 往 !SIGNPOST_2! 的 !STREET_2! 行駛",
	-- 972: After !DIST! !UNIT! keep right !NG_COMMAND_1! and continue on !STREET_2!
	["bl0p000y"] = "!DIST! !UNIT! 之後， !NG_COMMAND_1! 請保持右側行駛， 接著請在 !STREET_2! 行駛",
	-- 973: After !DIST! !UNIT! keep right !NG_COMMAND_1! and continue on !STREET_2! towards !SIGNPOST_2!
	["bl0p000z"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請保持右側行駛, 接著請在 !BREAK:200! 往 !SIGNPOST_2! 的 !STREET_2! 行駛",
    -- 974: Follow the course of the road
    ["g0000000"] = "請繼續順著前方道路行駛",
}

commands_ped = { -- Common commands for car & ped navigation.
	-- empty command
	["00000000"] = " ",
	-- 599: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1!
	["blo00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道",
	-- 600: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1!
	["blw00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉",
	-- 601: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1!
	["blu00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎",
	-- 602: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1!
	["bls00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎",
	-- 604: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1!
	["blq00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉",
	-- 605: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! , !STREET!
	["blo00a00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 !STREET!",
	-- 606: After !DIST! !UNIT! turn left !NG_COMMAND_1! and continue on !STREET!
	["blv00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 然後請繼續在 !STREET! 行走",
	-- 607: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! onto !STREET!
	["blw00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 進入 !STREET!",
	-- 608: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! and continue on !STREET!
	["blw00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 然後請繼續在 !STREET! 行走",
	-- 609: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! onto !STREET!
	["blu00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 進入 !STREET!",
	-- 610: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! and continue on !STREET!
	["blu00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 然後請繼續在 !STREET! 行走",
	-- 611: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! onto !STREET!
	["bls00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 進入 !STREET!",
	-- 612: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! and continue on !STREET!
	["bls00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 然後請繼續在 !STREET! 行走",
	-- 613: After !DIST! !UNIT! turn right !NG_COMMAND_1! and continue on !STREET!
	["blr00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 然後請繼續在 !STREET! 行走",
	-- 616: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! onto !STREET!
	["blq00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 進入 !STREET!",
	-- 617: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! and continue on !STREET!
	["blq00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 然後請繼續在 !STREET! 行走",
	-- 618: Now turn slightly right !NG_COMMAND_1! onto !STREET!
	["a0q00d00"] = "現在 !NG_COMMAND_1! 請小幅度右轉 進入 !STREET!",
	-- 619: Now turn sharply right !NG_COMMAND_1! onto !STREET!
	["a0s00d00"] = "現在 !NG_COMMAND_1! 請向右急轉彎 進入 !STREET!",
	-- 620: Now turn slightly left !NG_COMMAND_1! onto !STREET!
	["a0w00d00"] = "現在 !NG_COMMAND_1! 請小幅度左轉 進入 !STREET!",
	-- 622: Now turn sharply left !NG_COMMAND_1! onto !STREET!
	["a0u00d00"] = "現在 !NG_COMMAND_1! 請向左急轉彎 進入 !STREET!",
	-- 623: Now take the street in the middle !NG_COMMAND_1! , !STREET!
	["a0o00a00"] = "現在 !NG_COMMAND_1! 請走中間街道 !STREET!",
	-- 624: Now take the street in the middle !NG_COMMAND_1!
	["a0o00000"] = "現在 !NG_COMMAND_1! 請走中間街道",
	-- 625: Now turn left !NG_COMMAND_1! and continue on !STREET!
	["a0v00f00"] = "現在 !NG_COMMAND_1! 請向左轉 然後請繼續在 !STREET! 行走",
	-- 626: Now turn slightly left !NG_COMMAND_1! and continue on !STREET!
	["a0w00f00"] = "現在 !NG_COMMAND_1! 請小幅度左轉 然後請繼續在 !STREET! 行走",
	-- 627: Now turn sharply left !NG_COMMAND_1! and continue on !STREET!
	["a0u00f00"] = "現在 !NG_COMMAND_1! 請向左急轉彎 然後請繼續在 !STREET! 行走",
	-- 628: Now turn sharply right !NG_COMMAND_1! and continue on !STREET!
	["a0s00f00"] = "現在 !NG_COMMAND_1! 請向右急轉彎 然後請繼續在 !STREET! 行走",
	-- 629: Now turn right !NG_COMMAND_1! and continue on !STREET!
	["a0r00f00"] = "現在 !NG_COMMAND_1! 請向右轉 然後請繼續在 !STREET! 行走",
	-- 631: Now walk straight ahead and continue on !STREET!
	["a0n00f00"] = "現在 請直走 然後請繼續在 !STREET! 行走",
	-- 632: Now turn slightly right !NG_COMMAND_1! and continue on !STREET!
	["a0q00f00"] = "現在 !NG_COMMAND_1! 請小幅度右轉 然後請繼續在 !STREET! 行走",
	-- 633: Now walk around the roundabout and turn onto !STREET!
	["a0c00h00"] = "現在 請繞著圓環行走 然後 請轉 進入 !STREET!",
	-- 634: After !DIST! !UNIT! turn right !NG_COMMAND_1! , go through the building
	["blr00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 請穿越建築物,",
	-- 635: After !DIST! !UNIT! walk left around the roundabout
	["blb00000"] = "!DIST! !UNIT! 之後 請沿著圓環左側行走",
	-- 636: Now turn right !NG_COMMAND_1!
	["a0r00000"] = "現在 !NG_COMMAND_1! 請向右轉",
	-- 637: Now turn left !NG_COMMAND_1!
	["a0v00000"] = "現在 !NG_COMMAND_1! 請向左轉",
	-- 638: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! , !STREET!
	["blp00a00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道 !STREET!",
	-- 639: Now take the street on the right !NG_COMMAND_1! , !STREET!
	["a0p00a00"] = "現在 !NG_COMMAND_1! 請走右側街道 !STREET!",
	-- 640: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1!
	["blp00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道",
	-- 641: Now take the street on the right !NG_COMMAND_1!
	["a0p00000"] = "現在 !NG_COMMAND_1! 請走右側街道",
	-- 642: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! , !STREET!
	["blx00a00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道 !STREET!",
	-- 643: Now take the street on the left !NG_COMMAND_1! , !STREET!
	["a0x00a00"] = "現在 !NG_COMMAND_1! 請走左側街道 !STREET!",
	-- 644: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1!
	["blx00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道",
	-- 645: Now take the street on the left !NG_COMMAND_1!
	["a0x00000"] = "現在 !NG_COMMAND_1! 請走左側街道",
	-- 646: After !DIST! !UNIT! turn left !NG_COMMAND_1!
	["blv00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉",
	-- 647: After !DIST! !UNIT! turn right !NG_COMMAND_1!
	["blr00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉",
	-- 648: After !DIST! !UNIT! !NG_COMMAND_1! turn left onto !STREET!
	["blv00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 進入 !STREET!",
	-- 649: After !DIST! !UNIT! !NG_COMMAND_1! turn right onto !STREET!
	["blr00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 進入 !STREET!",
	-- 650: Now turn left onto !STREET!
	["a0v00d00"] = "現在 請向左轉 進入 !STREET!",
	-- 651: Now turn right onto !STREET!
	["a0r00d00"] = "現在 請向右轉 進入 !STREET!",
	-- 652: Now walk around the roundabout !PED_TURN_NO!
	["a0c00j00"] = "現在 請繞著圓環行走 !PED_TURN_NO!",
	-- 655: and then after !DIST! !UNIT! !NG_COMMAND_1! take the ferry
	["ll0m0000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請上渡船",
	-- 657: and then after !DIST! !UNIT! !NG_COMMAND_1! walk left around the roundabout
	["llb00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請沿著圓環左側行走",
	-- 658: and then after !DIST! !UNIT! !NG_COMMAND_1! walk around the roundabout
	["llc00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請繞著圓環行走",
	-- 659: and then after !DIST! !UNIT! !NG_COMMAND_1! walk right around the roundabout
	["lla00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請沿著圓環右側行走",
	-- 660: and then after !DIST! !UNIT! !NG_COMMAND_1! take the street in the middle
	["llo00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道",
	-- 661: and then after !DIST! !UNIT! !NG_COMMAND_1! turn left
	["llv00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉",
	-- 662: and then after !DIST! !UNIT! !NG_COMMAND_1! turn slightly left
	["llw00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉",
	-- 663: and then after !DIST! !UNIT! !NG_COMMAND_1! turn sharply left
	["llu00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎",
	-- 664: and then after !DIST! !UNIT! !NG_COMMAND_1! turn sharply right
	["lls00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎",
	-- 665: and then after !DIST! !UNIT! !NG_COMMAND_1! turn right
	["llr00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉",
	-- 666: and then after !DIST! !UNIT! !NG_COMMAND_1! take the street on the left
	["llx00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道",
	-- 667: and then after !DIST! !UNIT! !NG_COMMAND_1! take the street on the right
	["llp00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道",
	-- 669: and then after !DIST! !UNIT! !NG_COMMAND_1! walk straight ahead
	["lln00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走",
	-- 670: and then after !DIST! !UNIT! !NG_COMMAND_1! turn slightly right
	["llq00000"] = "然後 !DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉",
	-- 671: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! and take the lift
	["bln000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後 請搭乘電梯",
	-- 672: Now turn slightly right onto the footpath
	["a0q00g00"] = "現在 請小幅度右轉 進入小路",
	-- 673: Now turn right !NG_COMMAND_1! onto the footpath
	["a0r00g00"] = "現在 !NG_COMMAND_1! 請向右轉 進入小路",
	-- 674: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! and take the stairs
	["bln000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後 請走樓梯",
	-- 675: Now walk right around the roundabout and turn onto !STREET!
	["a0a00h00"] = "現在 請沿著圓環右側行走 然後 請轉 進入 !STREET!",
	-- 676: After !DIST! !UNIT! turn right !NG_COMMAND_1! , cross the park
	["blr00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 請穿越公園,",
	-- 677: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! , take the stairs
	["bln00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請走樓梯,",
	-- 678: Now turn left !NG_COMMAND_1! and take the escalator
	["a0v000t0"] = "現在 !NG_COMMAND_1! 請向左轉 然後 請走電扶梯",
	-- 679: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! and take the lift
	["blo000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 然後 請搭乘電梯",
	-- 680: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , go through the building
	["bls00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 請穿越建築物,",
	-- 681: Now take the street in the middle !NG_COMMAND_1! , cross the park
	["a0o00q00"] = "現在 !NG_COMMAND_1! 請走中間街道, 請穿越公園,",
	-- 682: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , take the escalator
	["blw00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 請走電扶梯,",
	-- 683: Now turn slightly left !NG_COMMAND_1! and take the escalator
	["a0w000t0"] = "現在 !NG_COMMAND_1! 請小幅度左轉 然後 請走電扶梯",
	-- 684: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! and take the lift
	["blw000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 然後 請搭乘電梯",
	-- 685: Now walk left around the roundabout !PED_TURN_NO!
	["a0b00j00"] = "現在 請沿著圓環左側行走 !PED_TURN_NO!",
	-- 686: Now walk left around the roundabout !NG_COMMAND_1! and turn onto !STREET!
	["a0b00h00"] = "現在 !NG_COMMAND_1! 請沿著圓環左側行走 然後 請轉 進入 !STREET!",
	-- 687: Now turn slightly right !NG_COMMAND_1! , cross the square
	["a0q00p00"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 請穿越廣場,",
	-- 688: Head !ORIENTATION!
	["f0000000"] = "請朝 !ORIENTATION! 行走",
	-- 689: Now turn slightly right !NG_COMMAND_1! , cross the park
	["a0q00q00"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 請穿越公園,",
	-- 690: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! and cross the park
	["blq000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 然後 請穿越公園",
	-- 691: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! and go through the building
	["blw000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 然後 請穿越建築物",
	-- 692: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , take the lift
	["blw00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 請搭乘電梯,",
	-- 693: Now turn sharply left !NG_COMMAND_1! and take the escalator
	["a0u000t0"] = "現在 !NG_COMMAND_1! 請向左急轉彎 然後 請走電扶梯",
	-- 694: Now walk straight ahead !NG_COMMAND_1! and cross the square
	["a0n000p0"] = "現在 !NG_COMMAND_1! 請直走 然後 請穿越廣場",
	-- 695: Now take the street on the right !NG_COMMAND_1! and go through the building
	["a0p000o0"] = "現在 !NG_COMMAND_1! 請走右側街道 然後 請穿越建築物",
	-- 696: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! and take the escalator
	["blw000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 然後 請走電扶梯",
	-- 697: Now turn left !NG_COMMAND_1! take the stairs
	["a0v00r00"] = "現在 !NG_COMMAND_1! 請向左轉, 請走樓梯,",
	-- 698: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! and cross the park
	["blo000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 然後 請穿越公園",
	-- 699: Now take the street in the middle !NG_COMMAND_1! and cross the square
	["a0o000p0"] = "現在 !NG_COMMAND_1! 請走中間街道 然後 請穿越廣場",
	-- 700: Now turn slightly right !NG_COMMAND_1! and go through the building
	["a0q000o0"] = "現在 !NG_COMMAND_1! 請小幅度右轉 然後 請穿越建築物",
	-- 701: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! , cross the park
	["bln00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請穿越公園,",
	-- 702: Now walk right around the roundabout !NG_COMMAND_1! !PED_TURN_NO!
	["a0a00j00"] = "現在 !NG_COMMAND_1! 請沿著圓環右側行走 !PED_TURN_NO!",
	-- 703: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! and take the escalator
	["blq000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 然後 請走電扶梯",
	-- 704: Now turn sharply right !NG_COMMAND_1! and take the escalator
	["a0s000t0"] = "現在 !NG_COMMAND_1! 請向右急轉彎 然後 請走電扶梯",
	-- 705: Now take the street in the middle !NG_COMMAND_1! and go through the building
	["a0o000o0"] = "現在 !NG_COMMAND_1! 請走中間街道 然後 請穿越建築物",
	-- 706: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! and go through the building
	["bln000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後 請穿越建築物",
	-- 707: Now walk straight ahead !NG_COMMAND_1! , cross the square
	["a0n00p00"] = "現在 !NG_COMMAND_1! 請直走, 請穿越廣場,",
	-- 708: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! and cross the park
	["bln000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後 請穿越公園",
	-- 709: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! and take the lift
	["blx000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道 然後 請搭乘電梯",
	-- 710: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! , take the escalator
	["blx00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道, 請走電扶梯,",
	-- 711: Now turn slightly right !NG_COMMAND_1! , take the escalator
	["a0q00t00"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 請走電扶梯,",
	-- 712: After !DIST! !UNIT! turn right !NG_COMMAND_1! and take the lift
	["blr000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 然後 請搭乘電梯",
	-- 713: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! and cross the park
	["blw000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 然後 請穿越公園",
	-- 714: Now turn slightly right !NG_COMMAND_1! , take the stairs
	["a0q00r00"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 請走樓梯,",
	-- 715: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! and take the stairs
	["blq000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 然後 請走樓梯",
	-- 716: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , take the stairs
	["blq00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 請走樓梯,",
	-- 717: Now turn !NG_COMMAND_1! onto the footpath
	["a0y00g00"] = "現在 !NG_COMMAND_1! 請轉 進入小路",
	-- 718: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! and cross the park
	["blu000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 然後 請穿越公園",
	-- 719: Now turn right !NG_COMMAND_1! and go through the building
	["a0r000o0"] = "現在 !NG_COMMAND_1! 請向右轉 然後 請穿越建築物",
	-- 720: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! and go through the building
	["blu000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 然後 請穿越建築物",
	-- 721: Now turn sharply right !NG_COMMAND_1! , go through the building
	["a0s00o00"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 請穿越建築物,",
	-- 722: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! and take the escalator
	["blu000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 然後 請走電扶梯",
	-- 723: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! and take the stairs
	["blo000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 然後 請走樓梯",
	-- 724: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! and take the stairs
	["bls000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 然後 請走樓梯",
	-- 725: After !DIST! !UNIT! turn left !NG_COMMAND_1! and cross the square
	["blv000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 然後 請穿越廣場",
	-- 726: After !DIST! !UNIT! turn right !NG_COMMAND_1! and cross the park
	["blr000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 然後 請穿越公園",
	-- 727: Now turn left !NG_COMMAND_1! and take the stairs
	["a0v000r0"] = "現在 !NG_COMMAND_1! 請向左轉 然後 請走樓梯",
	-- 728: Now take the street on the left !NG_COMMAND_1! , take the escalator
	["a0x00t00"] = "現在 !NG_COMMAND_1! 請走左側街道, 請走電扶梯,",
	-- 729: Now turn slightly left !NG_COMMAND_1! , cross the square
	["a0w00p00"] = "現在 !NG_COMMAND_1! 請小幅度左轉, 請穿越廣場,",
	-- 730: Now turn sharply right !NG_COMMAND_1! and cross the park
	["a0s000q0"] = "現在 !NG_COMMAND_1! 請向右急轉彎 然後 請穿越公園",
	-- 731: After !DIST! !UNIT! turn right !NG_COMMAND_1! and take the escalator
	["blr000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 然後 請走電扶梯",
	-- 732: After !DIST! !UNIT! turn right !NG_COMMAND_1! and go through the building
	["blr000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 然後 請穿越建築物",
	-- 733: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! and cross the park
	["blp000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道 然後 請穿越公園",
	-- 734: After !DIST! !UNIT! walk right around the roundabout !NG_COMMAND_1!
	["bla00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請沿著圓環右側行走",
	-- 735: Now take the street on the right !NG_COMMAND_1! and cross the square
	["a0p000p0"] = "現在 !NG_COMMAND_1! 請走右側街道 然後 請穿越廣場",
	-- 736: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! and go through the building
	["bls000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 然後 請穿越建築物",
	-- 737: Now walk straight ahead !NG_COMMAND_1! and take the stairs
	["a0n000r0"] = "現在 !NG_COMMAND_1! 請直走 然後 請走樓梯",
	-- 738: Now turn sharply right !NG_COMMAND_1! and go through the building
	["a0s000o0"] = "現在 !NG_COMMAND_1! 請向右急轉彎 然後 請穿越建築物",
	-- 739: Now turn right !NG_COMMAND_1! and take the lift
	["a0r000s0"] = "現在 !NG_COMMAND_1! 請向右轉 然後 請搭乘電梯",
	-- 740: Now turn slightly right !NG_COMMAND_1! and take the lift
	["a0q000s0"] = "現在 !NG_COMMAND_1! 請小幅度右轉 然後 請搭乘電梯",
	-- 741: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! , take the lift
	["blo00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道,  請搭乘電梯,",
	-- 742: Now walk straight ahead !NG_COMMAND_1! , take the stairs
	["a0n00r00"] = "現在 !NG_COMMAND_1! 請直走, 請走樓梯,",
	-- 743: After !DIST! !UNIT! turn right !NG_COMMAND_1! and take the stairs
	["blr000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 然後 請走樓梯",
	-- 744: Now take the street on the left !NG_COMMAND_1! and take the escalator
	["a0x000t0"] = "現在 !NG_COMMAND_1! 請走左側街道 然後 請走電扶梯",
	-- 745: After !DIST! !UNIT! turn left !NG_COMMAND_1! and cross the park
	["blv000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 然後 請穿越公園",
	-- 746: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! , take the escalator
	["bln00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請走電扶梯,",
	-- 747: Now turn sharply left !NG_COMMAND_1! and take the stairs
	["a0u000r0"] = "現在 !NG_COMMAND_1! 請向左急轉彎 然後 請走樓梯",
	-- 748: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! cross the park
	["blp00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道, 請穿越公園,",
	-- 749: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! , cross the square
	["blp00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道, 請穿越廣場,",
	-- 750: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! onto !STREET!
	["bln00d00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 進入 !STREET!",
	-- 751: Now take the street on the right !NG_COMMAND_1! , take the stairs
	["a0p00r00"] = "現在 !NG_COMMAND_1! 請走右側街道, 請走樓梯,",
	-- 752: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , cross the square
	["blq00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 請穿越廣場,",
	-- 753: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , cross the park
	["blq00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 請穿越公園,",
	-- 754: Now turn sharply right !NG_COMMAND_1! , take the stairs
	["a0s00r00"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 請走樓梯,",
	-- 755: Now turn !NG_COMMAND_1!
	["a0y00000"] = "現在 !NG_COMMAND_1! 請轉",
	-- 756: Now turn left !NG_COMMAND_1! , cross the square
	["a0v00p00"] = "現在 !NG_COMMAND_1! 請向左轉, 請穿越廣場,",
	-- 757: After !DIST! !UNIT! turn left !NG_COMMAND_1! and go through the building
	["blv000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 然後 請穿越建築物",
	-- 758: Now turn sharply right !NG_COMMAND_1! and take the lift
	["a0s000s0"] = "現在 !NG_COMMAND_1! 請向右急轉彎 然後 請搭乘電梯",
	-- 759: Now take the street on the left !NG_COMMAND_1! , take the stairs
	["a0x00r00"] = "現在 !NG_COMMAND_1! 請走左側街道, 請走樓梯,",
	-- 760: Now turn slightly right !NG_COMMAND_1! and cross the square
	["a0q000p0"] = "現在 !NG_COMMAND_1! 請小幅度右轉 然後 請穿越廣場",
	-- 761: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1!
	["bln00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走",
	-- 762: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! and cross the square
	["blx000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道 然後 請穿越廣場",
	-- 763: Now turn left !NG_COMMAND_1! and cross the park
	["a0v000q0"] = "現在 !NG_COMMAND_1! 請向左轉 然後 請穿越公園",
	-- 764: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , take the stairs
	["blu00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 請走樓梯,",
	-- 765: Now take the street in the middle !NG_COMMAND_1! and take the escalator
	["a0o000t0"] = "現在 !NG_COMMAND_1! 請走中間街道 然後 請走電扶梯",
	-- 766: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! onto the footpath
	["blu00g00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 進入小路",
	-- 767: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! , cross the square
	["bln00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請穿越廣場,",
	-- 768: Now turn right !NG_COMMAND_1! and take the escalator
	["a0r000t0"] = "現在 !NG_COMMAND_1! 請向右轉 然後 請走電扶梯",
	-- 769: Now take the street on the left !NG_COMMAND_1! , cross the square
	["a0x00p00"] = "現在 !NG_COMMAND_1! 請走左側街道, 請穿越廣場,",
	-- 770: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! and cross the park
	["blx000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道 然後 請穿越公園",
	-- 771: After !DIST! !UNIT! turn right !NG_COMMAND_1! , take the stairs
	["blr00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 請走樓梯,",
	-- 772: Now turn sharply right !NG_COMMAND_1! , cross the park
	["a0s00q00"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 請穿越公園,",
	-- 773: Now take the street in the middle !NG_COMMAND_1! and cross the park
	["a0o000q0"] = "現在 !NG_COMMAND_1! 請走中間街道 然後 請穿越公園",
	-- 774: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! and take the escalator
	["bls000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 然後 請走電扶梯",
	-- 775: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , cross the square
	["bls00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 請穿越廣場,",
	-- 776: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! and take the lift
	["bls000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 然後 請搭乘電梯",
	-- 777: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! and take the escalator
	["bln000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後 請走電扶梯",
	-- 778: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! and go through the building
	["blx000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道 然後 請穿越建築物",
	-- 779: Now take the street on the right !NG_COMMAND_1! , cross the square
	["a0p00p00"] = "現在 !NG_COMMAND_1! 請走右側街道, 請穿越廣場,",
	-- 780: Now take the street on the right !NG_COMMAND_1! , take the lift
	["a0p00s00"] = "現在 !NG_COMMAND_1! 請走右側街道, 請搭乘電梯,",
	-- 781: After !DIST! !UNIT! turn left !NG_COMMAND_1! , cross the square
	["blv00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 請穿越廣場,",
	-- 782: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! , take the stairs
	["blp00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道, 請走樓梯,",
	-- 783: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! and continue on !STREET!
	["bln00f00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後請繼續在 !STREET! 行走",
	-- 784: Now turn slightly left !NG_COMMAND_1! , take the stairs
	["a0w00r00"] = "現在 !NG_COMMAND_1! 請小幅度左轉,  請走樓梯,",
	-- 785: Now turn left !NG_COMMAND_1! , go through the building
	["a0v00o00"] = "現在 !NG_COMMAND_1! 請向左轉, 請穿越建築物,",
	-- 786: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! , take the escalator
	["blo00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道, 請走電扶梯,",
	-- 787: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! , cross the square
	["blo00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道,  請穿越廣場,",
	-- 788: Now walk straight ahead !NG_COMMAND_1! and take the lift
	["a0n000s0"] = "現在 !NG_COMMAND_1! 請直走 然後 請搭乘電梯",
	-- 789: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , take the stairs
	["bls00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎,  請走樓梯,",
	-- 790: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! and cross the square
	["blu000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 然後 請穿越廣場",
	-- 791: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! , cross the park
	["blx00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道,  請穿越公園,",
	-- 792: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , cross the park
	["bls00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 請穿越公園,",
	-- 793: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , cross the park
	["blu00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 請穿越公園,",
	-- 794: Now turn sharply left !NG_COMMAND_1! and cross the park
	["a0u000q0"] = "現在 !NG_COMMAND_1! 請向左急轉彎 然後 請穿越公園",
	-- 795: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! and take the escalator
	["blp000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道 然後 請走電扶梯",
	-- 796: Now turn slightly left !NG_COMMAND_1! , cross the park
	["a0w00q00"] = "現在 !NG_COMMAND_1! 請小幅度左轉, 請穿越公園,",
	-- 797: Now take the street in the middle !NG_COMMAND_1! , take the escalator
	["a0o00t00"] = "現在 !NG_COMMAND_1! 請走中間街道, 請走電扶梯,",
	-- 798: Now turn slightly right !NG_COMMAND_1! and cross the park
	["a0q000q0"] = "現在 !NG_COMMAND_1! 請小幅度右轉 然後 請穿越公園",
	-- 799: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! , cross the park
	["blo00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道, 請穿越公園,",
	-- 800: Now turn slightly left !NG_COMMAND_1! and cross the square
	["a0w000p0"] = "現在 !NG_COMMAND_1! 請小幅度左轉 然後 請穿越廣場",
	-- 801: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! , take the stairs
	["blx00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道, 請走樓梯,",
	-- 802: Now take the street in the middle !NG_COMMAND_1! , cross the square
	["a0o00p00"] = "現在 !NG_COMMAND_1! 請走中間街道, 請穿越廣場,",
	-- 803: After !DIST! !UNIT! turn left !NG_COMMAND_1! , take the stairs
	["blv00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 請走樓梯,",
	-- 804: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! , take the stairs
	["blo00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道, 請走樓梯,",
	-- 805: Head !ORIENTATION! towards !SIGNPOST!
	["f00000c0"] = "請朝 !ORIENTATION! 行走 !BREAK:200! 往 !SIGNPOST!",
	-- 806: Now turn slightly left !NG_COMMAND_1! , go through the building
	["a0w00o00"] = "現在 !NG_COMMAND_1! 請小幅度左轉, 請穿越建築物,",
	-- 807: After !DIST! !UNIT! turn left !NG_COMMAND_1! , take the escalator
	["blv00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 請走電扶梯,",
	-- 808: Now turn left !NG_COMMAND_1! and cross the square
	["a0v000p0"] = "現在 !NG_COMMAND_1! 請向左轉 然後 請穿越廣場",
	-- 809: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! take the lift
	["blq00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 請搭乘電梯,",
	-- 810: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! and cross the square
	["bls000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 然後 請穿越廣場",
	-- 811: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! onto the footpath
	["blq00g00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 進入小路",
	-- 812: Now turn sharply left !NG_COMMAND_1! and go through the building
	["a0u000o0"] = "現在 !NG_COMMAND_1! 請向左急轉彎 然後 請穿越建築物",
	-- 813: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! , take the lift
	["blx00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道, 請搭乘電梯,",
	-- 814: After !DIST! !UNIT! turn right !NG_COMMAND_1! , take the lift
	["blr00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 請搭乘電梯,",
	-- 815: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! , take the lift
	["bls00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎, 請搭乘電梯,",
	-- 816: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , take the lift
	["blu00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎,  請搭乘電梯,",
	-- 817: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! , take the escalator
	["blp00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道, 請走電扶梯,",
	-- 818: Now turn left !NG_COMMAND_1! , take the lift
	["a0v00s00"] = "現在 !NG_COMMAND_1! 請向左轉, 請搭乘電梯,",
	-- 819: Now take the street on the left !NG_COMMAND_1! and go through the building
	["a0x000o0"] = "現在 !NG_COMMAND_1! 請走左側街道 然後 請穿越建築物",
	-- 820: Now take the street on the right !NG_COMMAND_1! and cross the park
	["a0p000q0"] = "現在 !NG_COMMAND_1! 請走右側街道 然後 請穿越公園",
	-- 821: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , take the escalator
	["blu00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 請走電扶梯,",
	-- 822: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , go through the building
	["blq00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 請穿越建築物,",
	-- 823: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! , go through the building
	["blp00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道, 請穿越建築物,",
	-- 824: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! and take the escalator
	["blo000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 然後 請走電扶梯",
	-- 825: Now turn sharply left !NG_COMMAND_1! , take the lift
	["a0u00s00"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 請搭乘電梯,",
	-- 826: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! , go through the building
	["blx00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道, 請穿越建築物,",
	-- 827: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , go through the building
	["blu00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 請穿越建築物,",
	-- 828: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , go through the building
	["blw00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 請穿越建築物,",
	-- 829: After !DIST! !UNIT! turn left !NG_COMMAND_1! , go through the building
	["blv00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 請穿越建築物,",
	-- 830: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! , go through the building
	["blo00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道,   請穿越建築物,",
	-- 831: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! , cross the square
	["blu00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎, 請穿越廣場,",
	-- 832: Now turn sharply right !NG_COMMAND_1! and take the stairs
	["a0s000r0"] = "現在 !NG_COMMAND_1! 請向右急轉彎 然後 請走樓梯",
	-- 833: Now turn right !NG_COMMAND_1! , cross the square
	["a0r00p00"] = "現在 !NG_COMMAND_1! 請向右轉, 請穿越廣場,",
	-- 834: Now take the street in the middle !NG_COMMAND_1! and take the stairs
	["a0o000r0"] = "現在 !NG_COMMAND_1! 請走中間街道 然後 請走樓梯",
	-- 835: Now turn sharply right !NG_COMMAND_1! , cross the square
	["a0s00p00"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 請穿越廣場,",
	-- 836: After !DIST! !UNIT! turn left !NG_COMMAND_1! and take the stairs
	["blv000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 然後 請走樓梯",
	-- 837: Now turn right !NG_COMMAND_1! and cross the park
	["a0r000q0"] = "現在 !NG_COMMAND_1! 請向右轉 然後 請穿越公園",
	-- 838: Now turn right !NG_COMMAND_1! and take the stairs
	["a0r000r0"] = "現在 !NG_COMMAND_1! 請向右轉 然後 請走樓梯",
	-- 839: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! and cross the park
	["bls000q0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 然後 請穿越公園",
	-- 840: Now turn sharply left !NG_COMMAND_1! , cross the square
	["a0u00p00"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 請穿越廣場,",
	-- 841: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , take the stairs
	["blw00r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉,請走樓梯,",
	-- 842: Now walk straight ahead !NG_COMMAND_1! , cross the park
	["a0n00q00"] = "現在 !NG_COMMAND_1! 請直走, 請穿越公園,",
	-- 843: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! and take the stairs
	["blw000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 然後 請走樓梯",
	-- 844: Now take the street on the right !NG_COMMAND_1! , cross the park
	["a0p00q00"] = "現在 !NG_COMMAND_1! 請走右側街道, 請穿越公園,",
	-- 845: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! and cross the square
	["blp000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道 然後 請穿越廣場",
	-- 846: Now turn slightly right !NG_COMMAND_1! and take the escalator
	["a0q000t0"] = "現在 !NG_COMMAND_1! 請小幅度右轉 然後 請走電扶梯",
	-- 847: Now turn left !NG_COMMAND_1! and take the lift
	["a0v000s0"] = "現在 !NG_COMMAND_1! 請向左轉 然後 請搭乘電梯",
	-- 848: Now take the street on the left !NG_COMMAND_1! , cross the park
	["a0x00q00"] = "現在 !NG_COMMAND_1! 請走左側街道, 請穿越公園,",
	-- 849: Now turn right !NG_COMMAND_1! , cross the park
	["a0r00q00"] = "現在 !NG_COMMAND_1! 請向右轉, 請穿越公園,",
	-- 850: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! and cross the square
	["blq000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 然後 請穿越廣場",
	-- 851: Now turn sharply left !NG_COMMAND_1! , cross the park
	["a0u00q00"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 請穿越公園,",
	-- 852: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , cross the park
	["blw00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 請穿越公園,",
	-- 853: Now turn left !NG_COMMAND_1! , cross the park
	["a0v00q00"] = "現在 !NG_COMMAND_1! 請向左轉, 請穿越公園,",
	-- 854: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! and go through the building
	["blp000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道 然後 請穿越建築物",
	-- 855: Now turn right !NG_COMMAND_1! , take the stairs
	["a0r00r00"] = "現在 !NG_COMMAND_1! 請向右轉, 請走樓梯,",
	-- 856: Now turn left !NG_COMMAND_1! onto the footpath
	["a0v00g00"] = "現在 !NG_COMMAND_1! 請向左轉 進入小路",
	-- 857: Now turn sharply left !NG_COMMAND_1! , take the stairs
	["a0u00r00"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 請走樓梯,",
	-- 858: Now walk straight ahead !NG_COMMAND_1! and take the escalator
	["a0n000t0"] = "現在 !NG_COMMAND_1! 請直走 然後 請走電扶梯",
	-- 859: Now take the street on the left !NG_COMMAND_1! and take the stairs
	["a0x000r0"] = "現在 !NG_COMMAND_1! 請走左側街道 然後 請走樓梯",
	-- 860: After !DIST! !UNIT! turn right !NG_COMMAND_1! and cross the square
	["blr000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 然後 請穿越廣場",
	-- 861: Now take the street in the middle !NG_COMMAND_1! , take the stairs
	["a0o00r00"] = "現在 !NG_COMMAND_1! 請走中間街道, 請走樓梯,",
	-- 862: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! and go through the building
	["blq000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 然後 請穿越建築物",
	-- 863: Now turn slightly right !NG_COMMAND_1! , take the lift
	["a0q00s00"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 請搭乘電梯,",
	-- 864: Now turn right !NG_COMMAND_1! , take the lift
	["a0r00s00"] = "現在 !NG_COMMAND_1! 請向右轉, 請搭乘電梯,",
	-- 865: Now turn slightly right !NG_COMMAND_1! and take the stairs
	["a0q000r0"] = "現在 !NG_COMMAND_1! 請小幅度右轉 然後 請走樓梯",
	-- 866: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! and cross the square
	["blo000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 然後 請穿越廣場",
	-- 867: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! , cross the square
	["blw00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉, 請穿越廣場,",
	-- 868: Now take the street on the left !NG_COMMAND_1! , take the lift
	["a0x00s00"] = "現在 !NG_COMMAND_1! 請走左側街道, 請搭乘電梯,",
	-- 869: Now walk straight ahead !NG_COMMAND_1! onto !STREET!
	["a0n00d00"] = "現在 !NG_COMMAND_1! 請直走 進入 !STREET!",
	-- 870: Now turn sharply right !NG_COMMAND_1! , take the lift
	["a0s00s00"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 請搭乘電梯,",
	-- 871: Now turn slightly left !NG_COMMAND_1! , take the lift
	["a0w00s00"] = "現在 !NG_COMMAND_1! 請小幅度左轉, 請搭乘電梯,",
	-- 872: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! , take the escalator
	["blq00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉, 請走電扶梯,",
	-- 873: Now take the street in the middle !NG_COMMAND_1! , take the lift
	["a0o00s00"] = "現在 !NG_COMMAND_1! 請走中間街道, 請搭乘電梯,",
	-- 874: Now walk straight ahead !NG_COMMAND_1! , take the escalator
	["a0n00t00"] = "現在 !NG_COMMAND_1! 請直走, 請走電扶梯,",
	-- 875: After !DIST! !UNIT! turn sharply right !NG_COMMAND_1! onto the footpath
	["bls00g00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右急轉彎 進入小路",
	-- 876: After !DIST! !UNIT! take the street in the middle !NG_COMMAND_1! and go through the building
	["blo000o0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走中間街道 然後 請穿越建築物",
	-- 877: Now turn right !NG_COMMAND_1! , go through the building
	["a0r00o00"] = "現在 !NG_COMMAND_1! 請向右轉, 請穿越建築物,",
	-- 878: After !DIST! !UNIT! turn left !NG_COMMAND_1! and take the escalator
	["blv000t0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 然後 請走電扶梯",
	-- 879: Now turn slightly left !NG_COMMAND_1! and cross the park
	["a0w000q0"] = "現在 !NG_COMMAND_1! 請小幅度左轉 然後 請穿越公園",
	-- 880: Now turn right !NG_COMMAND_1! , take the escalator
	["a0r00t00"] = "現在 !NG_COMMAND_1! 請向右轉, 請走電扶梯,",
	-- 881: Now turn sharply right !NG_COMMAND_1! , take the escalator
	["a0s00t00"] = "現在 !NG_COMMAND_1! 請向右急轉彎, 請走電扶梯,",
	-- 882: Now turn sharply left !NG_COMMAND_1! , take the escalator
	["a0u00t00"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 請走電扶梯,",
	-- 883: Now turn left !NG_COMMAND_1! , take the escalator
	["a0v00t00"] = "現在 !NG_COMMAND_1! 請向左轉, 請走電扶梯,",
	-- 884: Now turn slightly right !NG_COMMAND_1! , go through the building
	["a0q00o00"] = "現在 !NG_COMMAND_1! 請小幅度右轉, 請穿越建築物,",
	-- 885: Now walk straight ahead !NG_COMMAND_1! , go through the building
	["a0n00o00"] = "現在 !NG_COMMAND_1! 請直走, 請穿越建築物,",
	-- 886: Now take the street on the right !NG_COMMAND_1! , go through the building
	["a0p00o00"] = "現在 !NG_COMMAND_1! 請走右側街道, 請穿越建築物,",
	-- 887: After !DIST! !UNIT! turn slightly right !NG_COMMAND_1! and take the lift
	["blq000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度右轉 然後 請搭乘電梯",
	-- 888: Now take the street on the right !NG_COMMAND_1! and take the lift
	["a0p000s0"] = "現在 !NG_COMMAND_1! 請走右側街道 然後 請搭乘電梯",
	-- 889: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! and take the lift
	["blu000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 然後 請搭乘電梯",
	-- 890: Now take the street on the left !NG_COMMAND_1! , go through the building
	["a0x00o00"] = "現在 !NG_COMMAND_1! 請走左側街道, 請穿越建築物,",
	-- 891: Now take the street on the right !NG_COMMAND_1! , take the escalator
	["a0p00t00"] = "現在 !NG_COMMAND_1! 請走右側街道, 請走電扶梯,",
	-- 892: Head !ORIENTATION! on !STREET! towards !SIGNPOST!
	["f0000bc0"] = "請朝 !ORIENTATION! 行走 在 !STREET! !BREAK:200! 往 !SIGNPOST!",
	-- 893: Now take the street in the middle !NG_COMMAND_1! , go through the building
	["a0o00o00"] = "現在 !NG_COMMAND_1! 請走中間街道, 請穿越建築物,",
	-- 894: Now take the street on the left !NG_COMMAND_1! and cross the square
	["a0x000p0"] = "現在 !NG_COMMAND_1! 請走左側街道 然後 請穿越廣場",
	-- 895: Now turn right !NG_COMMAND_1! and cross the square
	["a0r000p0"] = "現在 !NG_COMMAND_1! 請向右轉 然後 請穿越廣場",
	-- 896: Now turn sharply right !NG_COMMAND_1! and cross the square
	["a0s000p0"] = "現在 !NG_COMMAND_1! 請向右急轉彎 然後 請穿越廣場",
	-- 897: Now turn sharply left !NG_COMMAND_1! and cross the square
	["a0u000p0"] = "現在 !NG_COMMAND_1! 請向左急轉彎 然後 請穿越廣場",
	-- 898: After !DIST! !UNIT! turn left !NG_COMMAND_1! , cross the park
	["blv00q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 請穿越公園,",
	-- 899: Now walk straight ahead !NG_COMMAND_1! and cross the park
	["a0n000q0"] = "現在 !NG_COMMAND_1! 請直走 然後 請穿越公園",
	-- 900: Now turn sharply left onto the footpath
	["a0u00g00"] = "現在 請向左急轉彎 進入小路",
	-- 901: Now turn slightly left !NG_COMMAND_1! and go through the building
	["a0w000o0"] = "現在 !NG_COMMAND_1! 請小幅度左轉 然後 請穿越建築物",
	-- 902: After !DIST! !UNIT! turn right !NG_COMMAND_1! , take the escalator
	["blr00t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 請走電扶梯,",
	-- 903: Now turn sharply left !NG_COMMAND_1! and take the lift
	["a0u000s0"] = "現在 !NG_COMMAND_1! 請向左急轉彎 然後 請搭乘電梯",
	-- 904: Now take the street on the right !NG_COMMAND_1! and take the stairs
	["a0p000r0"] = "現在 !NG_COMMAND_1! 請走右側街道 然後 請走樓梯",
	-- 905: Now turn left !NG_COMMAND_1! and go through the building
	["a0v000o0"] = "現在 !NG_COMMAND_1! 請向左轉 然後 請穿越建築物",
	-- 906: After !DIST! !UNIT! turn right !NG_COMMAND_1! , cross the square
	["blr00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉, 請穿越廣場,",
	-- 907: Now walk straight ahead !NG_COMMAND_1! , take the lift
	["a0n00s00"] = "現在 !NG_COMMAND_1! 請直走, 請搭乘電梯,",
	-- 908: Now turn slightly left !NG_COMMAND_1! and take the stairs
	["a0w000r0"] = "現在 !NG_COMMAND_1! 請小幅度左轉 然後 請走樓梯",
	-- 909: Now take the street on the left !NG_COMMAND_1! and take the lift
	["a0x000s0"] = "現在 !NG_COMMAND_1! 請走左側街道 然後 請搭乘電梯",
	-- 910: Now turn slightly left onto the footpath
	["a0w00g00"] = "現在 請小幅度左轉 進入小路",
	-- 911: Now take the street in the middle !NG_COMMAND_1! and take the lift
	["a0o000s0"] = "現在 !NG_COMMAND_1! 請走中間街道 然後 請搭乘電梯",
	-- 912: After !DIST! !UNIT! turn left !NG_COMMAND_1! and take the lift
	["blv000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 然後 請搭乘電梯",
	-- 913: After !DIST! !UNIT! turn right !NG_COMMAND_1! onto the footpath
	["blr00g00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向右轉 進入小路",
	-- 914: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! and take the stairs
	["blp000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道 然後 請走樓梯",
	-- 915: Head !ORIENTATION! on !STREET!
	["f0000b00"] = "請朝 !ORIENTATION! 行走 在 !STREET!",
	-- 916: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! and take the stairs
	["blx000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道 然後 請走樓梯",
	-- 917: After !DIST! !UNIT! !NG_COMMAND_1! turn slightly left onto the footpath
	["blw00g00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 進入小路",
	-- 918: Now walk straight ahead !NG_COMMAND_1! and go through the building
	["a0n000o0"] = "現在 !NG_COMMAND_1! 請直走 然後 請穿越建築物",
	-- 919: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! and cross the square
	["bln000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走 然後 請穿越廣場",
	-- 920: After !DIST! !UNIT! walk around the roundabout !NG_COMMAND_1!
	["blc00000"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請繞著圓環行走",
	-- 921: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! , take the lift
	["bln00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請搭乘電梯,",
	-- 922: After !DIST! !UNIT! turn slightly left !NG_COMMAND_1! and cross the square
	["blw000p0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請小幅度左轉 然後 請穿越廣場",
	-- 923: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! , cross the square
	["blx00p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走左側街道, 請穿越廣場,",
	-- 924: Now take the street on the right !NG_COMMAND_1! and take the escalator
	["a0p000t0"] = "現在 !NG_COMMAND_1! 請走右側街道 然後 請走電扶梯",
	-- 925: After !DIST! !UNIT! turn left !NG_COMMAND_1! , take the lift
	["blv00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉, 請搭乘電梯,",
	-- 926: After !DIST! !UNIT! turn sharply left !NG_COMMAND_1! and take the stairs
	["blu000r0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左急轉彎 然後 請走樓梯",
	-- 927: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! and take the lift
	["blp000s0"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道 然後 請搭乘電梯",
	-- 928: After !DIST! !UNIT! walk straight ahead !NG_COMMAND_1! , go through the building
	["bln00o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請直走, 請穿越建築物,",
	-- 929: Now take the street on the left !NG_COMMAND_1! and cross the park
	["a0x000q0"] = "現在 !NG_COMMAND_1! 請走左側街道 然後 請穿越公園",
	-- 930: After !DIST! !UNIT! take the street on the right !NG_COMMAND_1! , take the lift
	["blp00s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請走右側街道, 請搭乘電梯,",
	-- 931: After !DIST! !UNIT! turn left !NG_COMMAND_1! onto the footpath
	["blv00g00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1! 請向左轉 進入小路",
	-- 932: Now turn slightly left !NG_COMMAND_1! and take the lift
	["a0w000s0"] = "現在 !NG_COMMAND_1! 請小幅度左轉 然後 請搭乘電梯",
	-- 933: Now walk straight ahead !NG_COMMAND_1!
	["a0n00000"] = "現在 !NG_COMMAND_1! 請直走",
	-- 934: Now turn sharply right onto the footpath
	["a0s00g00"] = "現在 請向右急轉彎 進入小路",
	-- 935: Now turn !NG_COMMAND_1! onto !STREET!
	["a0y00d00"] = "現在 !NG_COMMAND_1! 請轉 進入 !STREET!",
	-- 936: Now turn sharply left !NG_COMMAND_1! , go through the building
	["a0u00o00"] = "現在 !NG_COMMAND_1! 請向左急轉彎, 請穿越建築物,",
	-- 951: After !DIST! !UNIT! !NG_COMMAND_1! go through the building
	["bl000o00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1!  請穿越建築物",
	-- 952: After !DIST! !UNIT! !NG_COMMAND_1! cross the square
	["bl000p00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1!  請穿越廣場",
	-- 953: After !DIST! !UNIT! !NG_COMMAND_1! cross the park
	["bl000q00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1!  請穿越公園",
	-- 954: After !DIST! !UNIT! !NG_COMMAND_1! take the stairs
	["bl000r00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1!  請走樓梯",
	-- 955: After !DIST! !UNIT! !NG_COMMAND_1! take the lift
	["bl000s00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1!  請搭乘電梯",
	-- 956: After !DIST! !UNIT! !NG_COMMAND_1! take the escalator
	["bl000t00"] = "!DIST! !UNIT! 之後 !NG_COMMAND_1!  請搭乘電扶梯",
	-- 957: After !DIST! !UNIT! walk right around the roundabout and turn onto !STREET!
	["bla00h00"] = "!DIST! !UNIT! 之後， 請沿著圓環右側行走 然後 請轉 入 !STREET!",
	-- 958: After !DIST! !UNIT! walk right around the roundabout !NG_COMMAND_1! !PED_TURN_NO!
	["bla00j00"] = "!DIST! !UNIT! 之後， 請沿著圓環右側行走 !NG_COMMAND_1! !PED_TURN_NO!",
	-- 959: After !DIST! !UNIT! walk left around the roundabout !NG_COMMAND_1! and turn onto !STREET!
	["blb00h00"] = "!DIST! !UNIT! 之後， 請沿著圓環左側行走 !NG_COMMAND_1! 轉進 !STREET!",
	-- 960: After !DIST! !UNIT! walk left around the roundabout !PED_TURN_NO!
	["blb00j00"] = "!DIST! !UNIT! 之後， 請沿著圓環左側行走 !PED_TURN_NO!",
	-- 961: After !DIST! !UNIT! walk around the roundabout and turn onto !STREET!
	["blc00h00"] = "!DIST! !UNIT! 之後， 請沿著圓環行走 然後 請轉 入 !STREET!",
	-- 962: After !DIST! !UNIT! walk around the roundabout !PED_TURN_NO!
	["blc00j00"] = "!DIST! !UNIT! 之後， 請沿著圓環行走 !PED_TURN_NO!",
	-- 963: After !DIST! !UNIT! take the street on the left !NG_COMMAND_1! and take the escalator
	["blx000t0"] = "!DIST! !UNIT! 之後， 請走左側街道 !NG_COMMAND_1!  請搭乘電梯",
}
